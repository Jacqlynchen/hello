﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlconnect;
        MySqlCommand sqlcommand;
        MySqlDataAdapter sqldataadapter;
        string sqlQuery;
        DataTable dt = new DataTable();
        DataTable dtType = new DataTable();
        DataTable dtteamaway = new DataTable();
        DataTable dtteamhome = new DataTable();
        DataTable dtlastmatchdate = new DataTable();
        DataTable dtcountmatch = new DataTable();
        DataTable player = new DataTable();
        DataTable dtteam = new DataTable();
        DataTable dtminute = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
            cb_type.Items.Add("GO");
            cb_type.Items.Add("GP");
            cb_type.Items.Add("GW");
            cb_type.Items.Add("CR");
            cb_type.Items.Add("CY");
            cb_type.Items.Add("PM");
            sqlconnect = new MySqlConnection("server=localhost;uid=root;pwd=Sayacantik44;database=premier_league");
            sqlQuery = "Select * FROM team";
            sqlcommand = new MySqlCommand(sqlQuery, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            sqldataadapter.Fill(dtteamaway);

            cb_teamAway.DataSource = dtteamaway;
            cb_teamAway.DisplayMember = "team_name";
            cb_teamAway.ValueMember = "team_id";

            sqlQuery = "Select * FROM team";
            sqlcommand = new MySqlCommand(sqlQuery, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            sqldataadapter.Fill(dtteamhome);

            cb_teamHome.DataSource = dtteamhome;
            cb_teamHome.DisplayMember = "team_name";
            cb_teamHome.ValueMember = "team_id";

            dt.Columns.Add("Team");
            dt.Columns.Add("Player");
            dt.Columns.Add("Type");
            tb_matchID.Enabled = false;
            dtminute.Columns.Add("minute");
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                sqlQuery = "SELECT match_date FROM `match` ORDER BY match_date DESC LIMIT 1";
                sqlcommand = new MySqlCommand(sqlQuery, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                dtlastmatchdate = new DataTable();
                sqldataadapter.Fill(dtlastmatchdate);

                if (dtlastmatchdate.Rows.Count > 0)
                {
                    DateTime lastmatchdate = Convert.ToDateTime(dtlastmatchdate.Rows[0]["match_date"]);
                    DateTime tanggaldipilih = dateTimePicker1.Value;
                    if (tanggaldipilih < lastmatchdate)
                    {
                        MessageBox.Show("Selected date is earlier than the last match date");
                    }
                    else
                    {

                        string year = tanggaldipilih.Year.ToString();
                        try
                        {

                            sqlQuery = $"SELECT IFNULL(COUNT(*), 0) AS match_count FROM `match` WHERE YEAR(match_date) = '{tanggaldipilih.Year}'";
                            sqlcommand = new MySqlCommand(sqlQuery, sqlconnect);
                            sqldataadapter = new MySqlDataAdapter(sqlcommand);
                            dtcountmatch = new DataTable();
                            sqldataadapter.Fill(dtcountmatch);
                            int matchcount = Convert.ToInt32(dtcountmatch.Rows[0]["match_count"]) + 1;
                            string matchNumber = matchcount.ToString("000");
                            tb_matchID.Text = $"{year}{matchNumber}";
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }

                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cb_teamHome.SelectedItem != null && cb_teamAway.SelectedItem != null)
            {
                sqlQuery = "Select * team;";
                
                if(cb_teamHome.SelectedItem == cb_teamAway.SelectedItem)
                {
                    MessageBox.Show("Team tidak boleh sama");
                }
                else
                {
                    DataTable selectedTeams = new DataTable();
                    selectedTeams.Columns.Add("team_name");
                    selectedTeams.Columns.Add("team_id");

                    DataRow homeTeamRow = selectedTeams.NewRow();
                    homeTeamRow["team_name"] = cb_teamHome.Text;
                    homeTeamRow["team_id"] = cb_teamHome.SelectedValue.ToString();
                    selectedTeams.Rows.Add(homeTeamRow);

                    cb_team.DataSource = selectedTeams;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    cb_team.SelectedIndex = -1;
                }
            }
        }

        private void cb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamAway.SelectedItem != null && cb_teamHome.SelectedItem != null)
            {
                sqlQuery = "Select * team;";
               
                if (cb_teamAway.SelectedItem == cb_teamHome.SelectedItem)
                {
                    MessageBox.Show("Team tidak boleh sama");
                }
                else
                {
                    DataTable selectedTeams = new DataTable();
                    selectedTeams.Columns.Add("team_name");
                    selectedTeams.Columns.Add("team_id");

                    DataRow homeTeamRow = selectedTeams.NewRow();
                    homeTeamRow["team_name"] = cb_teamHome.Text;
                    homeTeamRow["team_id"] = cb_teamHome.SelectedValue.ToString();
                    selectedTeams.Rows.Add(homeTeamRow);

                    DataRow awayTeamRow = selectedTeams.NewRow();
                    awayTeamRow["team_name"] = cb_teamAway.Text;
                    awayTeamRow["team_id"] = cb_teamAway.SelectedValue.ToString();
                    selectedTeams.Rows.Add(awayTeamRow);

                    cb_team.DataSource = selectedTeams;
                    cb_team.DisplayMember = "team_name";
                    cb_team.ValueMember = "team_id";
                    cb_team.SelectedIndex = -1;
                }
            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            sqlQuery = $"Select player_name, player_id from player, team t WHERE player.team_id = t.team_id AND t.team_name = '{cb_team.Text}';";
            sqlconnect.Open();
            sqlcommand = new MySqlCommand(sqlQuery, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            player = new DataTable();
            sqldataadapter.Fill(player);
            cb_player.DataSource = player;
            cb_player.DisplayMember = "player_name";
            cb_player.ValueMember = "player_id";
            sqlconnect.Close();
        }

        private void cb_player_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_add_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(cb_team.Text, cb_player.Text, cb_type.Text);
            dataGridView1.DataSource= dt;
            dtminute.Rows.Add(tb_minute.Text);
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int rowIndex = dataGridView1.CurrentRow.Index;
                if (rowIndex >= 0 && rowIndex < dt.Rows.Count)
                {
                    dt.Rows.RemoveAt(rowIndex);
                }
            }
        }
        private string GetPlayerIdByName(string playerName)
        {
            foreach (DataRow row in player.Rows)
            {
                if (row["player_name"].ToString() == playerName)
                {
                    return row["player_id"].ToString();
                }
            }
            return null;
        }

        private string GetTeamIdByName(string teamName)
        {
            foreach (DataRow row in dtteamhome.Rows)
            {
                if (row["team_name"].ToString() == teamName)
                {
                    return row["team_id"].ToString();
                }
            }
            return null;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Masuk");
            if (dt.Rows.Count > 0 & dtminute.Rows.Count > 0)
            {
                if (dt.Rows.Count > 0 && dtminute.Rows.Count > 0)
                {
                    string matchid = tb_matchID.Text;
                    string matchdate = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                    string teamHomeId = cb_teamHome.SelectedValue.ToString();
                    string teamAwayId = cb_teamAway.SelectedValue.ToString();
                    string refereeId = "M002";
                    int goalHome = 0;
                    int goalAway = 0;

                    foreach (DataRow row in dt.Rows)
                    {
                        if (row["Team"].ToString() == cb_teamHome.Text && (row["Type"].ToString() == "GO" || row["Type"].ToString() == "GP" || row["Type"].ToString() == "GW"))
                        {
                            goalHome++;
                        }
                    }
                    foreach (DataRow row in dt.Rows)
                    {
                        if (row["Team"].ToString() == cb_teamAway.Text && (row["Type"].ToString() == "GO" || row["Type"].ToString() == "GP" || row["Type"].ToString() == "GW"))
                        {
                            goalAway++;
                        }
                    }

                    try
                    {
                        sqlQuery = $"INSERT INTO `match` (match_id, match_date, team_home, team_away, goal_home, goal_away, referee_id, `delete`) VALUES (@match_id, @match_date, @team_home, @team_away, @goal_home, @goal_away, @referee_id, 0)";
                        sqlconnect.Open();
                        sqlcommand = new MySqlCommand(sqlQuery, sqlconnect);
                        sqlcommand.Parameters.AddWithValue("@match_id", matchid);
                        sqlcommand.Parameters.AddWithValue("@match_date", matchdate);
                        sqlcommand.Parameters.AddWithValue("@team_home", teamHomeId);
                        sqlcommand.Parameters.AddWithValue("@team_away", teamAwayId);
                        sqlcommand.Parameters.AddWithValue("@goal_home", goalHome);
                        sqlcommand.Parameters.AddWithValue("@goal_away", goalAway);
                        sqlcommand.Parameters.AddWithValue("@referee_id", refereeId);
                        sqlcommand.ExecuteNonQuery();

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            DataRow row = dt.Rows[i];
                            DataRow minuteRow = dtminute.Rows[i];
                            string teamId = GetTeamIdByName(row["Team"].ToString());
                            string playerId = GetPlayerIdByName(row["Player"].ToString());
                            sqlQuery = "INSERT INTO dmatch (match_id, minute, team_id, player_id, type, `delete`) VALUES (@match_id, @minute, @team_id, @player_id, @type, 0)";
                            sqlcommand = new MySqlCommand(sqlQuery, sqlconnect);
                            sqlcommand.Parameters.AddWithValue("@match_id", matchid);
                            sqlcommand.Parameters.AddWithValue("@minute", minuteRow["minute"]);
                            sqlcommand.Parameters.AddWithValue("@team_id", teamId);
                            sqlcommand.Parameters.AddWithValue("@player_id", playerId);
                            sqlcommand.Parameters.AddWithValue("@type", row["Type"]);
                            sqlcommand.ExecuteNonQuery();
                        }

                        MessageBox.Show("Data inserted successfully.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        sqlconnect.Close();
                    }
                }
                else
                {
                    MessageBox.Show("No data to insert.");
                }


            }

        }
    }
}
