﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label_matchID = new System.Windows.Forms.Label();
            this.label_teamHome = new System.Windows.Forms.Label();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.label_matchDate = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label_teamAway = new System.Windows.Forms.Label();
            this.cb_teamAway = new System.Windows.Forms.ComboBox();
            this.label_minute = new System.Windows.Forms.Label();
            this.label_player = new System.Windows.Forms.Label();
            this.label_team = new System.Windows.Forms.Label();
            this.label_type = new System.Windows.Forms.Label();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.button_add = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(62, 237);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(732, 450);
            this.dataGridView1.TabIndex = 0;
            // 
            // label_matchID
            // 
            this.label_matchID.AutoSize = true;
            this.label_matchID.Location = new System.Drawing.Point(196, 86);
            this.label_matchID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_matchID.Name = "label_matchID";
            this.label_matchID.Size = new System.Drawing.Size(78, 20);
            this.label_matchID.TabIndex = 1;
            this.label_matchID.Text = "Match ID ";
            // 
            // label_teamHome
            // 
            this.label_teamHome.AutoSize = true;
            this.label_teamHome.Location = new System.Drawing.Point(196, 135);
            this.label_teamHome.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_teamHome.Name = "label_teamHome";
            this.label_teamHome.Size = new System.Drawing.Size(100, 20);
            this.label_teamHome.TabIndex = 2;
            this.label_teamHome.Text = "Team Home ";
            // 
            // tb_matchID
            // 
            this.tb_matchID.Location = new System.Drawing.Point(322, 90);
            this.tb_matchID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(212, 26);
            this.tb_matchID.TabIndex = 3;
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(939, 293);
            this.tb_minute.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(212, 26);
            this.tb_minute.TabIndex = 4;
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(322, 133);
            this.cb_teamHome.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(212, 28);
            this.cb_teamHome.TabIndex = 5;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // label_matchDate
            // 
            this.label_matchDate.AutoSize = true;
            this.label_matchDate.Location = new System.Drawing.Point(842, 90);
            this.label_matchDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_matchDate.Name = "label_matchDate";
            this.label_matchDate.Size = new System.Drawing.Size(96, 20);
            this.label_matchDate.TabIndex = 6;
            this.label_matchDate.Text = "Match Date ";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(973, 85);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(290, 26);
            this.dateTimePicker1.TabIndex = 7;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label_teamAway
            // 
            this.label_teamAway.AutoSize = true;
            this.label_teamAway.Location = new System.Drawing.Point(842, 135);
            this.label_teamAway.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_teamAway.Name = "label_teamAway";
            this.label_teamAway.Size = new System.Drawing.Size(95, 20);
            this.label_teamAway.TabIndex = 8;
            this.label_teamAway.Text = "Team Away ";
            // 
            // cb_teamAway
            // 
            this.cb_teamAway.FormattingEnabled = true;
            this.cb_teamAway.Location = new System.Drawing.Point(973, 135);
            this.cb_teamAway.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_teamAway.Name = "cb_teamAway";
            this.cb_teamAway.Size = new System.Drawing.Size(212, 28);
            this.cb_teamAway.TabIndex = 9;
            this.cb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cb_teamAway_SelectedIndexChanged);
            // 
            // label_minute
            // 
            this.label_minute.AutoSize = true;
            this.label_minute.Location = new System.Drawing.Point(852, 295);
            this.label_minute.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_minute.Name = "label_minute";
            this.label_minute.Size = new System.Drawing.Size(61, 20);
            this.label_minute.TabIndex = 10;
            this.label_minute.Text = "Minute ";
            // 
            // label_player
            // 
            this.label_player.AutoSize = true;
            this.label_player.Location = new System.Drawing.Point(852, 373);
            this.label_player.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_player.Name = "label_player";
            this.label_player.Size = new System.Drawing.Size(56, 20);
            this.label_player.TabIndex = 11;
            this.label_player.Text = "Player ";
            // 
            // label_team
            // 
            this.label_team.AutoSize = true;
            this.label_team.Location = new System.Drawing.Point(852, 336);
            this.label_team.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_team.Name = "label_team";
            this.label_team.Size = new System.Drawing.Size(53, 20);
            this.label_team.TabIndex = 12;
            this.label_team.Text = "Team ";
            // 
            // label_type
            // 
            this.label_type.AutoSize = true;
            this.label_type.Location = new System.Drawing.Point(852, 415);
            this.label_type.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_type.Name = "label_type";
            this.label_type.Size = new System.Drawing.Size(47, 20);
            this.label_type.TabIndex = 13;
            this.label_type.Text = "Type ";
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(939, 334);
            this.cb_team.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(212, 28);
            this.cb_team.TabIndex = 14;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(939, 370);
            this.cb_player.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(212, 28);
            this.cb_player.TabIndex = 15;
            this.cb_player.SelectedIndexChanged += new System.EventHandler(this.cb_player_SelectedIndexChanged);
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(939, 413);
            this.cb_type.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(212, 28);
            this.cb_type.TabIndex = 16;
            // 
            // button_add
            // 
            this.button_add.Location = new System.Drawing.Point(876, 499);
            this.button_add.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(120, 34);
            this.button_add.TabIndex = 17;
            this.button_add.Text = "Add";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // button_delete
            // 
            this.button_delete.Location = new System.Drawing.Point(1030, 499);
            this.button_delete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(120, 34);
            this.button_delete.TabIndex = 18;
            this.button_delete.Text = "Delete";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(939, 591);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(144, 34);
            this.btn_insert.TabIndex = 19;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1443, 840);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.button_add);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.label_type);
            this.Controls.Add(this.label_team);
            this.Controls.Add(this.label_player);
            this.Controls.Add(this.label_minute);
            this.Controls.Add(this.cb_teamAway);
            this.Controls.Add(this.label_teamAway);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label_matchDate);
            this.Controls.Add(this.cb_teamHome);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.label_teamHome);
            this.Controls.Add(this.label_matchID);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label_matchID;
        private System.Windows.Forms.Label label_teamHome;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.Label label_matchDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label_teamAway;
        private System.Windows.Forms.ComboBox cb_teamAway;
        private System.Windows.Forms.Label label_minute;
        private System.Windows.Forms.Label label_player;
        private System.Windows.Forms.Label label_team;
        private System.Windows.Forms.Label label_type;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button btn_insert;
    }
}

