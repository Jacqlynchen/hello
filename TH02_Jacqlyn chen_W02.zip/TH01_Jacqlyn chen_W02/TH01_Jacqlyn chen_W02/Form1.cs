﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01_Jacqlyn_chen_W02
{
    public partial class Form1 : Form
    {
        string tebakKata;
        List<char> simpenHuruf = new List<char>();
        public Form1()
        {
            InitializeComponent();
            pnl_word.Visible = true;
            pnl_keyboard.Visible = false;
        }

        private void pnl_word_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_play_Click(object sender, EventArgs e)
        {
            List<string> word = new List<string>(5);


            if (tb_word1.Text.Length != 5 || tb_word2.Text.Length != 5 || tb_word3.Text.Length != 5 || tb_word4.Text.Length != 5 || tb_word5.Text.Length != 5)
            {
                MessageBox.Show("tidak boleh melebihi 5 huruf dan tidak boleh kurang dari 5 huruf");
            } 

            else if (tb_word1.Text != "" && tb_word2.Text != "" && tb_word3.Text != "" && tb_word4.Text != "" && tb_word5.Text != "")
            {
                bool kembar = false;
                word.Add(tb_word1.Text.ToLower());

                if (!word.Contains(tb_word2.Text))
                {
                    word.Add(tb_word2.Text.ToLower());
                }
                else
                {
                    kembar = true;
                }
                if (!word.Contains(tb_word3.Text))
                {
                    word.Add(tb_word3.Text.ToLower());
                }
                else
                {
                    kembar = true;
                }
                if (!word.Contains(tb_word4.Text))
                {
                    word.Add(tb_word4.Text.ToLower());
                }
                else
                {
                    kembar = true;
                }
                if (!word.Contains(tb_word5.Text))
                {
                    word.Add(tb_word5.Text.ToLower());
                }
                else
                {
                    kembar = true;
                }
               
                if (kembar == true)
                {
                    MessageBox.Show("kata tidak boleh sama");
                }
                else
                {
                    MessageBox.Show("Ayo Main");
                    int angka = 0;
                    Random rnd = new Random(); 
                    angka = rnd.Next(1, 5) - 1;

                    tebakKata = word[angka];
                    char[] test = tebakKata.ToArray(); 

                    for (int i = 0; i < test.Length; i++)
                    {
                        simpenHuruf.Add(test[i]);
                    }

                    lb_clue.Text = tebakKata.ToUpper(); 
                    lb_clue.Visible = true;
                    pnl_word.Visible = false;
                    pnl_keyboard.Visible = true;
                }        
            }
        }

        private void btn_z_Click(object sender, EventArgs e)
        {          
            Button btn = (Button)sender;    
            string ubahKecil = btn.Text.ToLower();
            char[] huruf = ubahKecil.ToCharArray();

            for (int i = 0; i < simpenHuruf.Count; i++)
            {

                if (simpenHuruf[i] == huruf[0])
                {
                    simpenHuruf[i] = '0';
                    if (i == 0)
                    {
                        lb_var1.Text = btn.Text;
                    }
                    else if (i == 1)
                    {
                        lb_var2.Text = btn.Text;
                    }
                    else if(i == 2)
                    {
                        lb_var3.Text = btn.Text;
                    }
                    else if(i ==3)
                    {
                        lb_var4.Text = btn.Text;
                    }
                    else
                    {
                        lb_var5.Text = btn.Text;
                    }
                }            
            }

            int a = 0;
            for (int j = 0; j < simpenHuruf.Count; j++)
            {
                if (simpenHuruf[j] == '0')
                {
                    a++;
                }
            }

            if (a == 5)
            {
                MessageBox.Show("Yeay selesai");
            }
        }
    }
}
