﻿namespace TH03_Jacqlyn_chen_Week03
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_ucBank = new System.Windows.Forms.Label();
            this.lb_username = new System.Windows.Forms.Label();
            this.lb_password = new System.Windows.Forms.Label();
            this.tb_username = new System.Windows.Forms.TextBox();
            this.tb_password = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_register = new System.Windows.Forms.Button();
            this.pnl_login = new System.Windows.Forms.Panel();
            this.pnl_register = new System.Windows.Forms.Panel();
            this.lb_ucBank2 = new System.Windows.Forms.Label();
            this.btn_register2 = new System.Windows.Forms.Button();
            this.lb_username2 = new System.Windows.Forms.Label();
            this.lb_password2 = new System.Windows.Forms.Label();
            this.tb_passwordRegister = new System.Windows.Forms.TextBox();
            this.tb_usernameRegister = new System.Windows.Forms.TextBox();
            this.pnl_deposit = new System.Windows.Forms.Panel();
            this.tb_inputDeposit = new System.Windows.Forms.TextBox();
            this.lb_deposit = new System.Windows.Forms.Label();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.btn_logoutDeposit = new System.Windows.Forms.Button();
            this.lb_ucBank3 = new System.Windows.Forms.Label();
            this.pnl_windraw = new System.Windows.Forms.Panel();
            this.lb_rupiahWindraw = new System.Windows.Forms.Label();
            this.tb_inputWindraw = new System.Windows.Forms.TextBox();
            this.lb_inputwindraw = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.btn_windraw = new System.Windows.Forms.Button();
            this.btn_logoutWindraw = new System.Windows.Forms.Button();
            this.lb_ucBank5 = new System.Windows.Forms.Label();
            this.pnl_balance = new System.Windows.Forms.Panel();
            this.lb_rupiahBalance = new System.Windows.Forms.Label();
            this.lb_balance2 = new System.Windows.Forms.Label();
            this.btn_windrawBalance = new System.Windows.Forms.Button();
            this.btn_depositBalance = new System.Windows.Forms.Button();
            this.btn_logoutBalance = new System.Windows.Forms.Button();
            this.lb_ucBank4 = new System.Windows.Forms.Label();
            this.pnl_login.SuspendLayout();
            this.pnl_register.SuspendLayout();
            this.pnl_deposit.SuspendLayout();
            this.pnl_windraw.SuspendLayout();
            this.pnl_balance.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_ucBank
            // 
            this.lb_ucBank.AutoSize = true;
            this.lb_ucBank.Font = new System.Drawing.Font("Microsoft Tai Le", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucBank.Location = new System.Drawing.Point(92, 21);
            this.lb_ucBank.Name = "lb_ucBank";
            this.lb_ucBank.Size = new System.Drawing.Size(145, 41);
            this.lb_ucBank.TabIndex = 0;
            this.lb_ucBank.Text = "UC Bank";
            // 
            // lb_username
            // 
            this.lb_username.AutoSize = true;
            this.lb_username.Location = new System.Drawing.Point(16, 88);
            this.lb_username.Name = "lb_username";
            this.lb_username.Size = new System.Drawing.Size(95, 20);
            this.lb_username.TabIndex = 1;
            this.lb_username.Text = "Username : ";
            // 
            // lb_password
            // 
            this.lb_password.AutoSize = true;
            this.lb_password.Location = new System.Drawing.Point(16, 125);
            this.lb_password.Name = "lb_password";
            this.lb_password.Size = new System.Drawing.Size(86, 20);
            this.lb_password.TabIndex = 2;
            this.lb_password.Text = "Password :";
            // 
            // tb_username
            // 
            this.tb_username.Location = new System.Drawing.Point(117, 82);
            this.tb_username.Name = "tb_username";
            this.tb_username.Size = new System.Drawing.Size(191, 26);
            this.tb_username.TabIndex = 3;
            // 
            // tb_password
            // 
            this.tb_password.Location = new System.Drawing.Point(117, 122);
            this.tb_password.Name = "tb_password";
            this.tb_password.Size = new System.Drawing.Size(191, 26);
            this.tb_password.TabIndex = 4;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(99, 181);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(120, 33);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_register
            // 
            this.btn_register.Location = new System.Drawing.Point(101, 220);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(118, 33);
            this.btn_register.TabIndex = 6;
            this.btn_register.Text = "Register";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // pnl_login
            // 
            this.pnl_login.Controls.Add(this.lb_ucBank);
            this.pnl_login.Controls.Add(this.btn_register);
            this.pnl_login.Controls.Add(this.lb_username);
            this.pnl_login.Controls.Add(this.btn_login);
            this.pnl_login.Controls.Add(this.lb_password);
            this.pnl_login.Controls.Add(this.tb_password);
            this.pnl_login.Controls.Add(this.tb_username);
            this.pnl_login.Location = new System.Drawing.Point(39, 10);
            this.pnl_login.Name = "pnl_login";
            this.pnl_login.Size = new System.Drawing.Size(333, 275);
            this.pnl_login.TabIndex = 7;
            // 
            // pnl_register
            // 
            this.pnl_register.Controls.Add(this.lb_ucBank2);
            this.pnl_register.Controls.Add(this.btn_register2);
            this.pnl_register.Controls.Add(this.lb_username2);
            this.pnl_register.Controls.Add(this.lb_password2);
            this.pnl_register.Controls.Add(this.tb_passwordRegister);
            this.pnl_register.Controls.Add(this.tb_usernameRegister);
            this.pnl_register.Location = new System.Drawing.Point(37, 298);
            this.pnl_register.Name = "pnl_register";
            this.pnl_register.Size = new System.Drawing.Size(335, 226);
            this.pnl_register.TabIndex = 8;
            this.pnl_register.Visible = false;
            // 
            // lb_ucBank2
            // 
            this.lb_ucBank2.AutoSize = true;
            this.lb_ucBank2.Font = new System.Drawing.Font("Microsoft Tai Le", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucBank2.Location = new System.Drawing.Point(92, 21);
            this.lb_ucBank2.Name = "lb_ucBank2";
            this.lb_ucBank2.Size = new System.Drawing.Size(145, 41);
            this.lb_ucBank2.TabIndex = 0;
            this.lb_ucBank2.Text = "UC Bank";
            // 
            // btn_register2
            // 
            this.btn_register2.Location = new System.Drawing.Point(99, 181);
            this.btn_register2.Name = "btn_register2";
            this.btn_register2.Size = new System.Drawing.Size(120, 33);
            this.btn_register2.TabIndex = 6;
            this.btn_register2.Text = "Register";
            this.btn_register2.UseVisualStyleBackColor = true;
            this.btn_register2.Click += new System.EventHandler(this.btn_register2_Click);
            // 
            // lb_username2
            // 
            this.lb_username2.AutoSize = true;
            this.lb_username2.Location = new System.Drawing.Point(16, 88);
            this.lb_username2.Name = "lb_username2";
            this.lb_username2.Size = new System.Drawing.Size(95, 20);
            this.lb_username2.TabIndex = 1;
            this.lb_username2.Text = "Username : ";
            // 
            // lb_password2
            // 
            this.lb_password2.AutoSize = true;
            this.lb_password2.Location = new System.Drawing.Point(16, 125);
            this.lb_password2.Name = "lb_password2";
            this.lb_password2.Size = new System.Drawing.Size(86, 20);
            this.lb_password2.TabIndex = 2;
            this.lb_password2.Text = "Password :";
            // 
            // tb_passwordRegister
            // 
            this.tb_passwordRegister.Location = new System.Drawing.Point(117, 122);
            this.tb_passwordRegister.Name = "tb_passwordRegister";
            this.tb_passwordRegister.Size = new System.Drawing.Size(191, 26);
            this.tb_passwordRegister.TabIndex = 4;
            // 
            // tb_usernameRegister
            // 
            this.tb_usernameRegister.Location = new System.Drawing.Point(117, 82);
            this.tb_usernameRegister.Name = "tb_usernameRegister";
            this.tb_usernameRegister.Size = new System.Drawing.Size(191, 26);
            this.tb_usernameRegister.TabIndex = 3;
            // 
            // pnl_deposit
            // 
            this.pnl_deposit.Controls.Add(this.tb_inputDeposit);
            this.pnl_deposit.Controls.Add(this.lb_deposit);
            this.pnl_deposit.Controls.Add(this.btn_deposit);
            this.pnl_deposit.Controls.Add(this.btn_logoutDeposit);
            this.pnl_deposit.Controls.Add(this.lb_ucBank3);
            this.pnl_deposit.Location = new System.Drawing.Point(1022, 10);
            this.pnl_deposit.Name = "pnl_deposit";
            this.pnl_deposit.Size = new System.Drawing.Size(290, 275);
            this.pnl_deposit.TabIndex = 9;
            this.pnl_deposit.Visible = false;
            // 
            // tb_inputDeposit
            // 
            this.tb_inputDeposit.Location = new System.Drawing.Point(32, 165);
            this.tb_inputDeposit.Name = "tb_inputDeposit";
            this.tb_inputDeposit.Size = new System.Drawing.Size(191, 26);
            this.tb_inputDeposit.TabIndex = 7;
            // 
            // lb_deposit
            // 
            this.lb_deposit.AutoSize = true;
            this.lb_deposit.Location = new System.Drawing.Point(43, 133);
            this.lb_deposit.Name = "lb_deposit";
            this.lb_deposit.Size = new System.Drawing.Size(165, 20);
            this.lb_deposit.TabIndex = 7;
            this.lb_deposit.Text = "Input Deposit Amount";
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(72, 210);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(118, 33);
            this.btn_deposit.TabIndex = 9;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // btn_logoutDeposit
            // 
            this.btn_logoutDeposit.Location = new System.Drawing.Point(148, 79);
            this.btn_logoutDeposit.Name = "btn_logoutDeposit";
            this.btn_logoutDeposit.Size = new System.Drawing.Size(118, 33);
            this.btn_logoutDeposit.TabIndex = 8;
            this.btn_logoutDeposit.Text = "Log out";
            this.btn_logoutDeposit.UseVisualStyleBackColor = true;
            this.btn_logoutDeposit.Click += new System.EventHandler(this.btn_logoutDeposit_Click);
            // 
            // lb_ucBank3
            // 
            this.lb_ucBank3.AutoSize = true;
            this.lb_ucBank3.Font = new System.Drawing.Font("Microsoft Tai Le", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucBank3.Location = new System.Drawing.Point(45, 21);
            this.lb_ucBank3.Name = "lb_ucBank3";
            this.lb_ucBank3.Size = new System.Drawing.Size(145, 41);
            this.lb_ucBank3.TabIndex = 7;
            this.lb_ucBank3.Text = "UC Bank";
            // 
            // pnl_windraw
            // 
            this.pnl_windraw.Controls.Add(this.lb_rupiahWindraw);
            this.pnl_windraw.Controls.Add(this.tb_inputWindraw);
            this.pnl_windraw.Controls.Add(this.lb_inputwindraw);
            this.pnl_windraw.Controls.Add(this.lb_balance);
            this.pnl_windraw.Controls.Add(this.btn_windraw);
            this.pnl_windraw.Controls.Add(this.btn_logoutWindraw);
            this.pnl_windraw.Controls.Add(this.lb_ucBank5);
            this.pnl_windraw.Location = new System.Drawing.Point(385, 12);
            this.pnl_windraw.Name = "pnl_windraw";
            this.pnl_windraw.Size = new System.Drawing.Size(335, 262);
            this.pnl_windraw.TabIndex = 10;
            this.pnl_windraw.Visible = false;
            // 
            // lb_rupiahWindraw
            // 
            this.lb_rupiahWindraw.AutoSize = true;
            this.lb_rupiahWindraw.Location = new System.Drawing.Point(142, 121);
            this.lb_rupiahWindraw.Name = "lb_rupiahWindraw";
            this.lb_rupiahWindraw.Size = new System.Drawing.Size(65, 20);
            this.lb_rupiahWindraw.TabIndex = 13;
            this.lb_rupiahWindraw.Text = "Rp.0,00";
            // 
            // tb_inputWindraw
            // 
            this.tb_inputWindraw.Location = new System.Drawing.Point(76, 179);
            this.tb_inputWindraw.Name = "tb_inputWindraw";
            this.tb_inputWindraw.Size = new System.Drawing.Size(191, 26);
            this.tb_inputWindraw.TabIndex = 10;
            // 
            // lb_inputwindraw
            // 
            this.lb_inputwindraw.AutoSize = true;
            this.lb_inputwindraw.Location = new System.Drawing.Point(76, 156);
            this.lb_inputwindraw.Name = "lb_inputwindraw";
            this.lb_inputwindraw.Size = new System.Drawing.Size(179, 20);
            this.lb_inputwindraw.TabIndex = 10;
            this.lb_inputwindraw.Text = "Input Windraw Amount :";
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Location = new System.Drawing.Point(35, 121);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(67, 20);
            this.lb_balance.TabIndex = 7;
            this.lb_balance.Text = "Balance";
            // 
            // btn_windraw
            // 
            this.btn_windraw.Location = new System.Drawing.Point(101, 219);
            this.btn_windraw.Name = "btn_windraw";
            this.btn_windraw.Size = new System.Drawing.Size(118, 33);
            this.btn_windraw.TabIndex = 9;
            this.btn_windraw.Text = "Withdraw";
            this.btn_windraw.UseVisualStyleBackColor = true;
            this.btn_windraw.Click += new System.EventHandler(this.btn_windraw_Click);
            // 
            // btn_logoutWindraw
            // 
            this.btn_logoutWindraw.Location = new System.Drawing.Point(204, 72);
            this.btn_logoutWindraw.Name = "btn_logoutWindraw";
            this.btn_logoutWindraw.Size = new System.Drawing.Size(118, 33);
            this.btn_logoutWindraw.TabIndex = 8;
            this.btn_logoutWindraw.Text = "Log out";
            this.btn_logoutWindraw.UseVisualStyleBackColor = true;
            this.btn_logoutWindraw.Click += new System.EventHandler(this.btn_logoutWindraw_Click);
            // 
            // lb_ucBank5
            // 
            this.lb_ucBank5.AutoSize = true;
            this.lb_ucBank5.Font = new System.Drawing.Font("Microsoft Tai Le", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucBank5.Location = new System.Drawing.Point(92, 18);
            this.lb_ucBank5.Name = "lb_ucBank5";
            this.lb_ucBank5.Size = new System.Drawing.Size(145, 41);
            this.lb_ucBank5.TabIndex = 7;
            this.lb_ucBank5.Text = "UC Bank";
            // 
            // pnl_balance
            // 
            this.pnl_balance.Controls.Add(this.lb_rupiahBalance);
            this.pnl_balance.Controls.Add(this.lb_balance2);
            this.pnl_balance.Controls.Add(this.btn_windrawBalance);
            this.pnl_balance.Controls.Add(this.btn_depositBalance);
            this.pnl_balance.Controls.Add(this.btn_logoutBalance);
            this.pnl_balance.Controls.Add(this.lb_ucBank4);
            this.pnl_balance.Location = new System.Drawing.Point(726, 10);
            this.pnl_balance.Name = "pnl_balance";
            this.pnl_balance.Size = new System.Drawing.Size(290, 275);
            this.pnl_balance.TabIndex = 10;
            this.pnl_balance.Visible = false;
            // 
            // lb_rupiahBalance
            // 
            this.lb_rupiahBalance.AutoSize = true;
            this.lb_rupiahBalance.Location = new System.Drawing.Point(125, 133);
            this.lb_rupiahBalance.Name = "lb_rupiahBalance";
            this.lb_rupiahBalance.Size = new System.Drawing.Size(65, 20);
            this.lb_rupiahBalance.TabIndex = 12;
            this.lb_rupiahBalance.Text = "Rp.0,00";
            // 
            // lb_balance2
            // 
            this.lb_balance2.AutoSize = true;
            this.lb_balance2.Location = new System.Drawing.Point(33, 133);
            this.lb_balance2.Name = "lb_balance2";
            this.lb_balance2.Size = new System.Drawing.Size(67, 20);
            this.lb_balance2.TabIndex = 11;
            this.lb_balance2.Text = "Balance";
            // 
            // btn_windrawBalance
            // 
            this.btn_windrawBalance.Location = new System.Drawing.Point(72, 231);
            this.btn_windrawBalance.Name = "btn_windrawBalance";
            this.btn_windrawBalance.Size = new System.Drawing.Size(118, 33);
            this.btn_windrawBalance.TabIndex = 10;
            this.btn_windrawBalance.Text = "Withraw";
            this.btn_windrawBalance.UseVisualStyleBackColor = true;
            this.btn_windrawBalance.Click += new System.EventHandler(this.btn_windrawBalance_Click);
            // 
            // btn_depositBalance
            // 
            this.btn_depositBalance.Location = new System.Drawing.Point(72, 192);
            this.btn_depositBalance.Name = "btn_depositBalance";
            this.btn_depositBalance.Size = new System.Drawing.Size(118, 33);
            this.btn_depositBalance.TabIndex = 9;
            this.btn_depositBalance.Text = "Deposit";
            this.btn_depositBalance.UseVisualStyleBackColor = true;
            this.btn_depositBalance.Click += new System.EventHandler(this.btn_depositBalance_Click);
            // 
            // btn_logoutBalance
            // 
            this.btn_logoutBalance.Location = new System.Drawing.Point(148, 79);
            this.btn_logoutBalance.Name = "btn_logoutBalance";
            this.btn_logoutBalance.Size = new System.Drawing.Size(118, 33);
            this.btn_logoutBalance.TabIndex = 8;
            this.btn_logoutBalance.Text = "Log out";
            this.btn_logoutBalance.UseVisualStyleBackColor = true;
            this.btn_logoutBalance.Click += new System.EventHandler(this.btn_logoutBalance_Click);
            // 
            // lb_ucBank4
            // 
            this.lb_ucBank4.AutoSize = true;
            this.lb_ucBank4.Font = new System.Drawing.Font("Microsoft Tai Le", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucBank4.Location = new System.Drawing.Point(45, 21);
            this.lb_ucBank4.Name = "lb_ucBank4";
            this.lb_ucBank4.Size = new System.Drawing.Size(145, 41);
            this.lb_ucBank4.TabIndex = 7;
            this.lb_ucBank4.Text = "UC Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 508);
            this.Controls.Add(this.pnl_login);
            this.Controls.Add(this.pnl_register);
            this.Controls.Add(this.pnl_balance);
            this.Controls.Add(this.pnl_deposit);
            this.Controls.Add(this.pnl_windraw);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl_login.ResumeLayout(false);
            this.pnl_login.PerformLayout();
            this.pnl_register.ResumeLayout(false);
            this.pnl_register.PerformLayout();
            this.pnl_deposit.ResumeLayout(false);
            this.pnl_deposit.PerformLayout();
            this.pnl_windraw.ResumeLayout(false);
            this.pnl_windraw.PerformLayout();
            this.pnl_balance.ResumeLayout(false);
            this.pnl_balance.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_ucBank;
        private System.Windows.Forms.Label lb_username;
        private System.Windows.Forms.Label lb_password;
        private System.Windows.Forms.TextBox tb_username;
        private System.Windows.Forms.TextBox tb_password;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.Panel pnl_login;
        private System.Windows.Forms.Panel pnl_register;
        private System.Windows.Forms.Label lb_ucBank2;
        private System.Windows.Forms.Button btn_register2;
        private System.Windows.Forms.Label lb_username2;
        private System.Windows.Forms.Label lb_password2;
        private System.Windows.Forms.TextBox tb_passwordRegister;
        private System.Windows.Forms.TextBox tb_usernameRegister;
        private System.Windows.Forms.Panel pnl_deposit;
        private System.Windows.Forms.TextBox tb_inputDeposit;
        private System.Windows.Forms.Label lb_deposit;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Button btn_logoutDeposit;
        private System.Windows.Forms.Label lb_ucBank3;
        private System.Windows.Forms.Panel pnl_windraw;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Button btn_windraw;
        private System.Windows.Forms.Button btn_logoutWindraw;
        private System.Windows.Forms.Label lb_ucBank5;
        private System.Windows.Forms.Label lb_inputwindraw;
        private System.Windows.Forms.TextBox tb_inputWindraw;
        private System.Windows.Forms.Panel pnl_balance;
        private System.Windows.Forms.Label lb_balance2;
        private System.Windows.Forms.Button btn_windrawBalance;
        private System.Windows.Forms.Button btn_depositBalance;
        private System.Windows.Forms.Button btn_logoutBalance;
        private System.Windows.Forms.Label lb_ucBank4;
        private System.Windows.Forms.Label lb_rupiahWindraw;
        private System.Windows.Forms.Label lb_rupiahBalance;
    }
}

