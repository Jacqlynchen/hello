﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_Jacqlyn_chen_Week03
{
    public partial class Form1 : Form
    {
        List<string> register = new List<string>();
        public Form1()
        {
            InitializeComponent();
            data.Columns.Add("nama");
            data.Columns.Add("password");
            data.Columns.Add("Saldo");
        }

        DataTable data = new DataTable();

        
        private void btn_register_Click(object sender, EventArgs e)
        {
            pnl_login.Visible = false;
            pnl_register.Visible = true;
            pnl_register.Top = 6;
            pnl_register.Left = 26;
            pnl_deposit.Top = 6;
            pnl_deposit.Left = 26;
            pnl_windraw.Top = 6;
            pnl_windraw.Left = 26;
            pnl_balance.Top = 6;
            pnl_balance.Left = 26;
        }
        int angka = 0;
        private void btn_login_Click(object sender, EventArgs e)
        {          
            bool benar = false;
            for (int i = 0; i < data.Rows.Count; i++)
            {
                
                if (tb_username.Text == data.Rows[i][0].ToString() && tb_password.Text ==  data.Rows[i][1].ToString()) 
                {
                    benar = true;
                    angka = i;
                    break;
                }
                else
                {
                    benar = false;
                }
            }         
            if (benar == true)
            {
                MessageBox.Show("Login Success"); 
                pnl_login.Visible = false;
                pnl_balance.Visible = true;
            }
            else
            {
                MessageBox.Show("Username and Password not found!");
            }
        }

        private void btn_register2_Click(object sender, EventArgs e)
        {
            bool sama = false;
            string userRegis = tb_usernameRegister.Text;
            for(int i = 0;i < data.Rows.Count; i++)
            {
                if(userRegis == data.Rows[i][0].ToString())
                {
                    sama = true;
                    break;
                }
                else
                {
                    sama = false;


                }
            }
            if (sama == false)
            {
                data.Rows.Add(userRegis, tb_passwordRegister.Text, 0);
                MessageBox.Show("Register Success");
            }
            else
            {
                MessageBox.Show("Username has been used");
            }
            tb_usernameRegister.Clear();
            tb_passwordRegister.Clear();
            pnl_login.Visible = true;
            pnl_register.Visible = false;
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            double hasil;
            hasil = Convert.ToDouble(data.Rows[angka][2]) + Convert.ToDouble(tb_inputDeposit.Text.ToString());
            data.Rows[angka][2] = hasil;
            int nominaldeposit = Convert.ToInt32(tb_inputDeposit.Text);
            hasil += nominaldeposit;
            string nominalnyaa = hasil.ToString("C");
            lb_rupiahBalance.Text = nominalnyaa;
            if (nominaldeposit <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
            else
            {
                MessageBox.Show("Succesfully Add Deposit");
            }
            lb_rupiahBalance.Text = Convert.ToDouble(data.Rows[angka][2]).ToString("C2").Remove(1,0);
            pnl_deposit.Visible = false;
            pnl_login.Visible = false;
            pnl_register.Visible = false;
            pnl_balance.Visible = true;
        }

        private void btn_logoutDeposit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            pnl_deposit.Visible = false;
            pnl_balance.Visible = false;
            pnl_register.Visible = false;
            pnl_windraw.Visible = false;
            pnl_login.Visible = true;
            tb_username.Clear();
            tb_password.Clear();
        }

        private void btn_windrawBalance_Click(object sender, EventArgs e)
        {
            pnl_balance.Visible = false;
            pnl_windraw.Visible = true;
            lb_rupiahWindraw.Text = (Convert.ToDouble(data.Rows[angka][2].ToString())).ToString("C2").Remove(1,0);
        }

        private void btn_depositBalance_Click(object sender, EventArgs e)
        {
            pnl_login.Visible = false;
            pnl_balance.Visible = false;
            pnl_deposit.Visible = true;
            tb_inputDeposit.Clear();
        }

        private void btn_logoutWindraw_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil.");
            pnl_deposit.Visible = false;
            pnl_balance.Visible = false;
            pnl_register.Visible = false;
            pnl_windraw.Visible = false;
            pnl_login.Visible = true;
            tb_username.Clear();
            tb_password.Clear();
        }

        private void btn_logoutBalance_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            pnl_deposit.Visible = false;
            pnl_balance.Visible = false;
            pnl_register.Visible = false;
            pnl_windraw.Visible = false;
            pnl_login.Visible = true;
            tb_username.Clear();
            tb_password.Clear();
        }

        private void btn_windraw_Click(object sender, EventArgs e)
        {
            double uang = Convert.ToDouble(data.Rows[angka][2].ToString());
            double hasil = Convert.ToDouble(tb_inputWindraw.Text);
            if (hasil < 0 || uang <= 0)
            {
                MessageBox.Show("Saldo tidak cukup");
            }
            else
            {
                uang = uang - hasil;
                data.Rows[angka][2] = uang;
                lb_rupiahBalance.Text = uang.ToString("C2").Remove(1,0);
                pnl_balance.Visible = true;
                pnl_windraw.Visible = false;
            }
        }

        
    }
}
