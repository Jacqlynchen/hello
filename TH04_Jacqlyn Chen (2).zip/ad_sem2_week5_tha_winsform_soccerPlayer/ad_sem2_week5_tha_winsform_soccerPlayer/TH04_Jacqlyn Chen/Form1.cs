﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Proxies;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ad_sem2_week5_winsform_soccerPlayer
{
    public partial class Form1 : Form
    {
        List<Team> listTeam = new List<Team>();

        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Team newTeam1 = new Team("Real Madrid", "Spain", "Madrid");
            Team newTeam2 = new Team("Manchester United", "England", "Manchester");
            Team newTeam3 = new Team("Liverpool FC", "England", "Livepool");
            listTeam.Add(newTeam1);
            listTeam.Add(newTeam2);
            listTeam.Add(newTeam3);
            newTeam1.player.Add(new Player("Thibat Courtouis", "01", "GK"));
            newTeam1.player.Add(new Player("Eder Militao", "03", "DF"));
            newTeam1.player.Add(new Player("David Alaba", "04", "DF"));
            newTeam1.player.Add(new Player("Dani Carvajal", "11", "GK"));
            newTeam1.player.Add(new Player("Antoni Rudiger", "22", "DF"));
            newTeam1.player.Add(new Player("Toni Kroos", "08", "MF"));
            newTeam1.player.Add(new Player("Marco Asensio", "11", "MF"));
            newTeam1.player.Add(new Player("Karim Benzema", "09", "FW"));
            newTeam1.player.Add(new Player("Lucas Vazquez", "17", "FW"));
            newTeam1.player.Add(new Player("Luka Modric", "10", "MF"));
            newTeam1.player.Add(new Player("Rodrygo", "21", "FW"));
            newTeam2.player.Add(new Player("David De Gea", "01", "GK"));
            newTeam2.player.Add(new Player("Dean Henderson", "26", "GK"));
            newTeam2.player.Add(new Player("Rodrygo", "21", "FW"));
            newTeam2.player.Add(new Player("Victor Lindelof", "02", "DF"));
            newTeam2.player.Add(new Player("Eric Bailly", "03", "DF"));
            newTeam2.player.Add(new Player("Raphael Varane", "19", "DF"));
            newTeam2.player.Add(new Player("Lisandro Martinez", "06", "DF"));
            newTeam2.player.Add(new Player("Bruno Fernandes", "08", "MF"));
            newTeam2.player.Add(new Player("Christian Eriksen", "14", "MF"));
            newTeam2.player.Add(new Player("Casemiro", "18", "MF"));
            newTeam2.player.Add(new Player("Marcus Rashford", "10", "FW"));
            newTeam3.player.Add(new Player("Allison", "01", "GK"));
            newTeam3.player.Add(new Player("Virgil Van Dijk", "04", "DF"));
            newTeam3.player.Add(new Player("Joel Matip", "31", "DF"));
            newTeam3.player.Add(new Player("Trent Alexander-Arnold", "66", "DF"));
            newTeam3.player.Add(new Player("Ibrahima Konate", "05", "DF"));
            newTeam3.player.Add(new Player("Thiago", "06", "MF"));
            newTeam3.player.Add(new Player("Fabinho", "03", "MF"));
            newTeam3.player.Add(new Player("James Milnder", "07", "MF"));
            newTeam3.player.Add(new Player("Jordan Henderson", "14", "MF"));
            newTeam3.player.Add(new Player("Mohammed Salah", "11", "FW"));
            newTeam3.player.Add(new Player("Darwin Nunez", "27", "FW"));

            foreach (Team team in listTeam)
            {
                if (!comboBoxCountry.Items.Contains(team.teamCountry))
                {
                    comboBoxCountry.Items.Add(team.teamCountry);
                }
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonAddTeam_Click(object sender, EventArgs e)
        {
            if (textBoxNameTeam.Text == "" || textBoxCountryTeam.Text == "" || textBoxCityTeam.Text == "")
            {
                MessageBox.Show("You must fill all the required fields", "Error Message");
            }
            else
            {
                bool teamChecker = true;
                foreach (Team team in listTeam)
                {
                    if (team.teamName == textBoxNameTeam.Text && team.teamCountry == textBoxCountryTeam.Text)
                    {
                        teamChecker = false;
                    }
                }
                if (teamChecker == true)
                {
                    Team newTeam = new Team(textBoxNameTeam.Text, textBoxCountryTeam.Text, textBoxCityTeam.Text);
                    listTeam.Add(newTeam);
                    if (!comboBoxCountry.Items.Contains(newTeam.teamCountry))
                    {
                        comboBoxCountry.Items.Add(newTeam.teamCountry);
                    }
                    comboBoxTeam.Items.Clear();
                    foreach (var x in listTeam)
                    {
                        if (x.teamCountry == comboBoxCountry.Text)
                        {
                            comboBoxTeam.Items.Add(x.teamName);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Team Already Exist", "Error Message");
                }
                textBoxNameTeam.Text = "";
                textBoxCountryTeam.Text = "";
                textBoxCityTeam.Text = "";
            }
        }

        private void buttonAddPlayer_Click(object sender, EventArgs e)
        {
            string selectedteam = comboBoxTeam.Text;
            Team chooseTeam = null;
           

            if (textBoxPlayerName.Text == "" || textBoxPlayerNumber.Text == "" || comboBoxPlayerPosition.Text == "")
            {
                MessageBox.Show("You must fill all the required fields", "Error Message");
            }
            else
            {
                bool playerExist = true;
                foreach (Team team in listTeam)
                {
                    if (team.teamName == comboBoxTeam.Text)
                    {
                        foreach (Player _player in team.player)
                        {
                            if (_player.playerNum == textBoxPlayerNumber.Text)
                            {
                                playerExist = false;
                            }                          
                        }
                    }
                }
                if (playerExist == true)
                {
                    Player newPlayer = new Player(textBoxPlayerName.Text, textBoxPlayerNumber.Text, comboBoxPlayerPosition.Text);
                    for (int i = 0; i < listTeam.Count; i++)
                    {
                        if (comboBoxCountry.Text == listTeam[i].teamCountry && comboBoxTeam.Text == listTeam[i].teamName)
                        {
                            listTeam[i].player.Add(newPlayer);
                            listBox_namaPlayer.Items.Clear();
                            foreach (Team team in listTeam)
                            {
                                if (team.teamName == comboBoxTeam.Text && team.teamCountry == comboBoxCountry.Text)
                                {
                                    foreach (Player _player in team.player)
                                    {
                                        listBox_namaPlayer.Items.Add("(" + _player.playerNum + ")" + _player.playerName + "," + _player.playerPos);
                                    }
                                    listBox_namaPlayer.Sorted = true;
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Player with same number is found", "Error Message");
                }
                textBoxPlayerName.Text = "";
                textBoxPlayerNumber.Text = "";
                comboBoxPlayerPosition.Text = "";
            } 
        }

        private void comboBoxCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox_namaPlayer.Items.Clear();
            comboBoxTeam.Items.Clear();
            foreach (var x in listTeam)
            {
                if (x.teamCountry == comboBoxCountry.Text)
                {
                    comboBoxTeam.Items.Add(x.teamName);
                }
            }
        }

        private void comboBoxTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox_namaPlayer.Items.Clear();
            foreach (Team team in listTeam)
            {
                if (team.teamName == comboBoxTeam.Text && team.teamCountry == comboBoxCountry.Text)
                {
                    foreach (Player _player in team.player)
                    {
                        listBox_namaPlayer.Items.Add("(" + _player.playerNum + ")" + _player.playerName + "," + _player.playerPos);
                    }
                    listBox_namaPlayer.Sorted = true;
                }
            }
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (listBox_namaPlayer.Items.Count <= 11)
            {
                MessageBox.Show("Unable to remove player because player is less then 11", "Error Message");
            }
            else
            {
                foreach (Team team in listTeam)
                {
                    if (team.teamName == comboBoxTeam.Text)
                    {
                        foreach (Player _player in team.player)
                        {
                            if (listBox_namaPlayer.SelectedItem.ToString().Contains("(" + _player.playerNum + ")" + _player.playerName + "," + _player.playerPos))
                            {
                                team.player.Remove(_player);
                                break;
                            }
                        }
                    }
                }
                listBox_namaPlayer.Items.RemoveAt(listBox_namaPlayer.SelectedIndex);
            }
        }
    }

    public class Team
    {
        public string teamName;
        public string teamCountry;
        public string teamCity;
        public List<Player> player = new List<Player>();
        public Team(string _teamName, string _teamCountry, string _teamCity)
        {
            teamName = _teamName;
            teamCountry = _teamCountry;
            teamCity = _teamCity;
        }
    }
    public class Player
    {
        public string playerName;
        public string playerNum;
        public string playerPos;

        public Player(string _playerName, string _playerNum, string _playerPos)
        {
            playerName = _playerName;
            playerNum = _playerNum;
            playerPos = _playerPos;
        }
    }
}
