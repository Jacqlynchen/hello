﻿namespace TH09_Jacqlyn_Chen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirttoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgrv_quantity = new System.Windows.Forms.DataGridView();
            this.label_subTotal = new System.Windows.Forms.Label();
            this.label_total = new System.Windows.Forms.Label();
            this.textBox_subTotal = new System.Windows.Forms.TextBox();
            this.textBox_total = new System.Windows.Forms.TextBox();
            this.label_item1 = new System.Windows.Forms.Label();
            this.label_item2 = new System.Windows.Forms.Label();
            this.label_item3 = new System.Windows.Forms.Label();
            this.label_price1 = new System.Windows.Forms.Label();
            this.label_price2 = new System.Windows.Forms.Label();
            this.label_price3 = new System.Windows.Forms.Label();
            this.button_Tshirt1 = new System.Windows.Forms.Button();
            this.button_TShirt2 = new System.Windows.Forms.Button();
            this.button_Tshirt3 = new System.Windows.Forms.Button();
            this.label_uploadImage = new System.Windows.Forms.Label();
            this.button_upload = new System.Windows.Forms.Button();
            this.label_itemPrice = new System.Windows.Forms.Label();
            this.label_itemName = new System.Windows.Forms.Label();
            this.textBox_itemPrice = new System.Windows.Forms.TextBox();
            this.textBox_itemName = new System.Windows.Forms.TextBox();
            this.button_addToCardUpload = new System.Windows.Forms.Button();
            this.pictureBox_upload = new System.Windows.Forms.PictureBox();
            this.pictureBox_item3 = new System.Windows.Forms.PictureBox();
            this.pictureBox_item2 = new System.Windows.Forms.PictureBox();
            this.pictureBox_item1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_jewelry3 = new System.Windows.Forms.Button();
            this.button_jewelry2 = new System.Windows.Forms.Button();
            this.button_jewelry1 = new System.Windows.Forms.Button();
            this.button_shoes3 = new System.Windows.Forms.Button();
            this.button_shoes2 = new System.Windows.Forms.Button();
            this.button_shoes1 = new System.Windows.Forms.Button();
            this.button_longPants3 = new System.Windows.Forms.Button();
            this.button_longPants2 = new System.Windows.Forms.Button();
            this.button_longPants1 = new System.Windows.Forms.Button();
            this.button_pants3 = new System.Windows.Forms.Button();
            this.button_pants2 = new System.Windows.Forms.Button();
            this.button_pants1 = new System.Windows.Forms.Button();
            this.button_shirt3 = new System.Windows.Forms.Button();
            this.button_shirt2 = new System.Windows.Forms.Button();
            this.button_shirt1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button_remove = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrv_quantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_upload)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_item3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_item2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_item1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.bottomWearToolStripMenuItem,
            this.toolStripMenuItem3,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1121, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirttoolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(102, 29);
            this.toolStripMenuItem1.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirttoolStripMenuItem
            // 
            this.shirttoolStripMenuItem.Name = "shirttoolStripMenuItem";
            this.shirttoolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirttoolStripMenuItem.Text = "Shirt";
            this.shirttoolStripMenuItem.Click += new System.EventHandler(this.shirttoolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(133, 29);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(119, 29);
            this.toolStripMenuItem3.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgrv_quantity
            // 
            this.dgrv_quantity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgrv_quantity.Location = new System.Drawing.Point(596, 46);
            this.dgrv_quantity.Name = "dgrv_quantity";
            this.dgrv_quantity.RowHeadersWidth = 62;
            this.dgrv_quantity.RowTemplate.Height = 28;
            this.dgrv_quantity.Size = new System.Drawing.Size(359, 219);
            this.dgrv_quantity.TabIndex = 1;
            // 
            // label_subTotal
            // 
            this.label_subTotal.AutoSize = true;
            this.label_subTotal.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_subTotal.Location = new System.Drawing.Point(589, 281);
            this.label_subTotal.Name = "label_subTotal";
            this.label_subTotal.Size = new System.Drawing.Size(182, 37);
            this.label_subTotal.TabIndex = 2;
            this.label_subTotal.Text = "Sub-Total :";
            // 
            // label_total
            // 
            this.label_total.AutoSize = true;
            this.label_total.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_total.Location = new System.Drawing.Point(654, 334);
            this.label_total.Name = "label_total";
            this.label_total.Size = new System.Drawing.Size(117, 37);
            this.label_total.TabIndex = 3;
            this.label_total.Text = "Total :";
            // 
            // textBox_subTotal
            // 
            this.textBox_subTotal.Location = new System.Drawing.Point(776, 288);
            this.textBox_subTotal.Name = "textBox_subTotal";
            this.textBox_subTotal.Size = new System.Drawing.Size(179, 26);
            this.textBox_subTotal.TabIndex = 4;
            // 
            // textBox_total
            // 
            this.textBox_total.Location = new System.Drawing.Point(776, 344);
            this.textBox_total.Name = "textBox_total";
            this.textBox_total.Size = new System.Drawing.Size(179, 26);
            this.textBox_total.TabIndex = 5;
            // 
            // label_item1
            // 
            this.label_item1.AutoSize = true;
            this.label_item1.Location = new System.Drawing.Point(9, 243);
            this.label_item1.Name = "label_item1";
            this.label_item1.Size = new System.Drawing.Size(51, 20);
            this.label_item1.TabIndex = 10;
            this.label_item1.Text = "label1";
            // 
            // label_item2
            // 
            this.label_item2.AutoSize = true;
            this.label_item2.Location = new System.Drawing.Point(185, 243);
            this.label_item2.Name = "label_item2";
            this.label_item2.Size = new System.Drawing.Size(51, 20);
            this.label_item2.TabIndex = 11;
            this.label_item2.Text = "label2";
            // 
            // label_item3
            // 
            this.label_item3.AutoSize = true;
            this.label_item3.Location = new System.Drawing.Point(364, 243);
            this.label_item3.Name = "label_item3";
            this.label_item3.Size = new System.Drawing.Size(51, 20);
            this.label_item3.TabIndex = 12;
            this.label_item3.Text = "label3";
            // 
            // label_price1
            // 
            this.label_price1.AutoSize = true;
            this.label_price1.Location = new System.Drawing.Point(9, 273);
            this.label_price1.Name = "label_price1";
            this.label_price1.Size = new System.Drawing.Size(51, 20);
            this.label_price1.TabIndex = 13;
            this.label_price1.Text = "label4";
            // 
            // label_price2
            // 
            this.label_price2.AutoSize = true;
            this.label_price2.Location = new System.Drawing.Point(185, 273);
            this.label_price2.Name = "label_price2";
            this.label_price2.Size = new System.Drawing.Size(51, 20);
            this.label_price2.TabIndex = 14;
            this.label_price2.Text = "label5";
            // 
            // label_price3
            // 
            this.label_price3.AutoSize = true;
            this.label_price3.Location = new System.Drawing.Point(364, 273);
            this.label_price3.Name = "label_price3";
            this.label_price3.Size = new System.Drawing.Size(51, 20);
            this.label_price3.TabIndex = 15;
            this.label_price3.Text = "label6";
            // 
            // button_Tshirt1
            // 
            this.button_Tshirt1.Location = new System.Drawing.Point(57, 308);
            this.button_Tshirt1.Name = "button_Tshirt1";
            this.button_Tshirt1.Size = new System.Drawing.Size(117, 36);
            this.button_Tshirt1.TabIndex = 16;
            this.button_Tshirt1.Text = "Add to Cart";
            this.button_Tshirt1.UseVisualStyleBackColor = true;
            this.button_Tshirt1.Visible = false;
            this.button_Tshirt1.Click += new System.EventHandler(this.button_item1_Click);
            // 
            // button_TShirt2
            // 
            this.button_TShirt2.Location = new System.Drawing.Point(233, 308);
            this.button_TShirt2.Name = "button_TShirt2";
            this.button_TShirt2.Size = new System.Drawing.Size(117, 36);
            this.button_TShirt2.TabIndex = 17;
            this.button_TShirt2.Text = "Add to Cart";
            this.button_TShirt2.UseVisualStyleBackColor = true;
            this.button_TShirt2.Visible = false;
            this.button_TShirt2.Click += new System.EventHandler(this.button_TShirt2_Click);
            // 
            // button_Tshirt3
            // 
            this.button_Tshirt3.Location = new System.Drawing.Point(412, 308);
            this.button_Tshirt3.Name = "button_Tshirt3";
            this.button_Tshirt3.Size = new System.Drawing.Size(117, 36);
            this.button_Tshirt3.TabIndex = 18;
            this.button_Tshirt3.Text = "Add to Cart";
            this.button_Tshirt3.UseVisualStyleBackColor = true;
            this.button_Tshirt3.Visible = false;
            this.button_Tshirt3.Click += new System.EventHandler(this.button_Tshirt3_Click);
            // 
            // label_uploadImage
            // 
            this.label_uploadImage.AutoSize = true;
            this.label_uploadImage.Location = new System.Drawing.Point(92, 22);
            this.label_uploadImage.Name = "label_uploadImage";
            this.label_uploadImage.Size = new System.Drawing.Size(109, 20);
            this.label_uploadImage.TabIndex = 21;
            this.label_uploadImage.Text = "Upload Image";
            this.label_uploadImage.UseWaitCursor = true;
            // 
            // button_upload
            // 
            this.button_upload.Location = new System.Drawing.Point(296, 19);
            this.button_upload.Name = "button_upload";
            this.button_upload.Size = new System.Drawing.Size(88, 31);
            this.button_upload.TabIndex = 22;
            this.button_upload.Text = "Upload";
            this.button_upload.UseVisualStyleBackColor = true;
            this.button_upload.UseWaitCursor = true;
            this.button_upload.Click += new System.EventHandler(this.button_upload_Click);
            // 
            // label_itemPrice
            // 
            this.label_itemPrice.AutoSize = true;
            this.label_itemPrice.Location = new System.Drawing.Point(264, 149);
            this.label_itemPrice.Name = "label_itemPrice";
            this.label_itemPrice.Size = new System.Drawing.Size(80, 20);
            this.label_itemPrice.TabIndex = 23;
            this.label_itemPrice.Text = "Item Price";
            this.label_itemPrice.UseWaitCursor = true;
            // 
            // label_itemName
            // 
            this.label_itemName.AutoSize = true;
            this.label_itemName.Location = new System.Drawing.Point(264, 73);
            this.label_itemName.Name = "label_itemName";
            this.label_itemName.Size = new System.Drawing.Size(87, 20);
            this.label_itemName.TabIndex = 24;
            this.label_itemName.Text = "Item Name";
            this.label_itemName.UseWaitCursor = true;
            // 
            // textBox_itemPrice
            // 
            this.textBox_itemPrice.Location = new System.Drawing.Point(249, 180);
            this.textBox_itemPrice.Name = "textBox_itemPrice";
            this.textBox_itemPrice.Size = new System.Drawing.Size(135, 26);
            this.textBox_itemPrice.TabIndex = 25;
            this.textBox_itemPrice.UseWaitCursor = true;
            this.textBox_itemPrice.TextChanged += new System.EventHandler(this.textBox_itemPrice_TextChanged);
            this.textBox_itemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_itemPrice_KeyPress);
            // 
            // textBox_itemName
            // 
            this.textBox_itemName.Location = new System.Drawing.Point(249, 105);
            this.textBox_itemName.Name = "textBox_itemName";
            this.textBox_itemName.Size = new System.Drawing.Size(135, 26);
            this.textBox_itemName.TabIndex = 26;
            this.textBox_itemName.UseWaitCursor = true;
            this.textBox_itemName.TextChanged += new System.EventHandler(this.textBox_itemName_TextChanged);
            // 
            // button_addToCardUpload
            // 
            this.button_addToCardUpload.Location = new System.Drawing.Point(268, 236);
            this.button_addToCardUpload.Name = "button_addToCardUpload";
            this.button_addToCardUpload.Size = new System.Drawing.Size(116, 31);
            this.button_addToCardUpload.TabIndex = 27;
            this.button_addToCardUpload.Text = "Add To Card";
            this.button_addToCardUpload.UseVisualStyleBackColor = true;
            this.button_addToCardUpload.UseWaitCursor = true;
            this.button_addToCardUpload.Click += new System.EventHandler(this.button_addToCardUpload_Click);
            // 
            // pictureBox_upload
            // 
            this.pictureBox_upload.Location = new System.Drawing.Point(70, 57);
            this.pictureBox_upload.Name = "pictureBox_upload";
            this.pictureBox_upload.Size = new System.Drawing.Size(161, 211);
            this.pictureBox_upload.TabIndex = 20;
            this.pictureBox_upload.TabStop = false;
            this.pictureBox_upload.UseWaitCursor = true;
            // 
            // pictureBox_item3
            // 
            this.pictureBox_item3.Image = global::TH09_Jacqlyn_Chen.Properties.Resources.drinkWater;
            this.pictureBox_item3.Location = new System.Drawing.Point(368, 18);
            this.pictureBox_item3.Name = "pictureBox_item3";
            this.pictureBox_item3.Size = new System.Drawing.Size(161, 213);
            this.pictureBox_item3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_item3.TabIndex = 9;
            this.pictureBox_item3.TabStop = false;
            // 
            // pictureBox_item2
            // 
            this.pictureBox_item2.Image = global::TH09_Jacqlyn_Chen.Properties.Resources.rings;
            this.pictureBox_item2.Location = new System.Drawing.Point(189, 18);
            this.pictureBox_item2.Name = "pictureBox_item2";
            this.pictureBox_item2.Size = new System.Drawing.Size(161, 213);
            this.pictureBox_item2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_item2.TabIndex = 8;
            this.pictureBox_item2.TabStop = false;
            // 
            // pictureBox_item1
            // 
            this.pictureBox_item1.Image = global::TH09_Jacqlyn_Chen.Properties.Resources.coffePeriodik;
            this.pictureBox_item1.Location = new System.Drawing.Point(13, 18);
            this.pictureBox_item1.Name = "pictureBox_item1";
            this.pictureBox_item1.Size = new System.Drawing.Size(161, 211);
            this.pictureBox_item1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_item1.TabIndex = 7;
            this.pictureBox_item1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_jewelry3);
            this.panel1.Controls.Add(this.label_price3);
            this.panel1.Controls.Add(this.button_jewelry2);
            this.panel1.Controls.Add(this.label_price2);
            this.panel1.Controls.Add(this.button_jewelry1);
            this.panel1.Controls.Add(this.label_price1);
            this.panel1.Controls.Add(this.button_shoes3);
            this.panel1.Controls.Add(this.label_item3);
            this.panel1.Controls.Add(this.button_shoes2);
            this.panel1.Controls.Add(this.label_item2);
            this.panel1.Controls.Add(this.button_shoes1);
            this.panel1.Controls.Add(this.label_item1);
            this.panel1.Controls.Add(this.button_longPants3);
            this.panel1.Controls.Add(this.button_longPants2);
            this.panel1.Controls.Add(this.pictureBox_item3);
            this.panel1.Controls.Add(this.button_longPants1);
            this.panel1.Controls.Add(this.pictureBox_item2);
            this.panel1.Controls.Add(this.button_pants3);
            this.panel1.Controls.Add(this.pictureBox_item1);
            this.panel1.Controls.Add(this.button_pants2);
            this.panel1.Controls.Add(this.button_Tshirt3);
            this.panel1.Controls.Add(this.button_pants1);
            this.panel1.Controls.Add(this.button_Tshirt1);
            this.panel1.Controls.Add(this.button_shirt3);
            this.panel1.Controls.Add(this.button_TShirt2);
            this.panel1.Controls.Add(this.button_shirt2);
            this.panel1.Controls.Add(this.button_shirt1);
            this.panel1.Location = new System.Drawing.Point(22, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(547, 375);
            this.panel1.TabIndex = 28;
            // 
            // button_jewelry3
            // 
            this.button_jewelry3.Location = new System.Drawing.Point(412, 308);
            this.button_jewelry3.Name = "button_jewelry3";
            this.button_jewelry3.Size = new System.Drawing.Size(117, 36);
            this.button_jewelry3.TabIndex = 45;
            this.button_jewelry3.Text = "Add to Cart";
            this.button_jewelry3.UseVisualStyleBackColor = true;
            this.button_jewelry3.Visible = false;
            this.button_jewelry3.Click += new System.EventHandler(this.button_jewelry3_Click);
            // 
            // button_jewelry2
            // 
            this.button_jewelry2.Location = new System.Drawing.Point(233, 308);
            this.button_jewelry2.Name = "button_jewelry2";
            this.button_jewelry2.Size = new System.Drawing.Size(117, 36);
            this.button_jewelry2.TabIndex = 44;
            this.button_jewelry2.Text = "Add to Cart";
            this.button_jewelry2.UseVisualStyleBackColor = true;
            this.button_jewelry2.Visible = false;
            this.button_jewelry2.Click += new System.EventHandler(this.button_jewelry2_Click);
            // 
            // button_jewelry1
            // 
            this.button_jewelry1.Location = new System.Drawing.Point(57, 308);
            this.button_jewelry1.Name = "button_jewelry1";
            this.button_jewelry1.Size = new System.Drawing.Size(117, 36);
            this.button_jewelry1.TabIndex = 43;
            this.button_jewelry1.Text = "Add to Cart";
            this.button_jewelry1.UseVisualStyleBackColor = true;
            this.button_jewelry1.Visible = false;
            this.button_jewelry1.Click += new System.EventHandler(this.button_jewelry1_Click);
            // 
            // button_shoes3
            // 
            this.button_shoes3.Location = new System.Drawing.Point(412, 308);
            this.button_shoes3.Name = "button_shoes3";
            this.button_shoes3.Size = new System.Drawing.Size(117, 36);
            this.button_shoes3.TabIndex = 42;
            this.button_shoes3.Text = "Add to Cart";
            this.button_shoes3.UseVisualStyleBackColor = true;
            this.button_shoes3.Visible = false;
            this.button_shoes3.Click += new System.EventHandler(this.button_shoes3_Click);
            // 
            // button_shoes2
            // 
            this.button_shoes2.Location = new System.Drawing.Point(233, 308);
            this.button_shoes2.Name = "button_shoes2";
            this.button_shoes2.Size = new System.Drawing.Size(117, 36);
            this.button_shoes2.TabIndex = 41;
            this.button_shoes2.Text = "Add to Cart";
            this.button_shoes2.UseVisualStyleBackColor = true;
            this.button_shoes2.Visible = false;
            this.button_shoes2.Click += new System.EventHandler(this.button_shoes2_Click);
            // 
            // button_shoes1
            // 
            this.button_shoes1.Location = new System.Drawing.Point(57, 308);
            this.button_shoes1.Name = "button_shoes1";
            this.button_shoes1.Size = new System.Drawing.Size(117, 36);
            this.button_shoes1.TabIndex = 40;
            this.button_shoes1.Text = "Add to Cart";
            this.button_shoes1.UseVisualStyleBackColor = true;
            this.button_shoes1.Visible = false;
            this.button_shoes1.Click += new System.EventHandler(this.button_shoes1_Click);
            // 
            // button_longPants3
            // 
            this.button_longPants3.Location = new System.Drawing.Point(412, 308);
            this.button_longPants3.Name = "button_longPants3";
            this.button_longPants3.Size = new System.Drawing.Size(117, 36);
            this.button_longPants3.TabIndex = 39;
            this.button_longPants3.Text = "Add to Cart";
            this.button_longPants3.UseVisualStyleBackColor = true;
            this.button_longPants3.Visible = false;
            this.button_longPants3.Click += new System.EventHandler(this.button_longPants3_Click);
            // 
            // button_longPants2
            // 
            this.button_longPants2.Location = new System.Drawing.Point(233, 308);
            this.button_longPants2.Name = "button_longPants2";
            this.button_longPants2.Size = new System.Drawing.Size(117, 36);
            this.button_longPants2.TabIndex = 38;
            this.button_longPants2.Text = "Add to Cart";
            this.button_longPants2.UseVisualStyleBackColor = true;
            this.button_longPants2.Visible = false;
            this.button_longPants2.Click += new System.EventHandler(this.button_longPants2_Click);
            // 
            // button_longPants1
            // 
            this.button_longPants1.Location = new System.Drawing.Point(57, 308);
            this.button_longPants1.Name = "button_longPants1";
            this.button_longPants1.Size = new System.Drawing.Size(117, 36);
            this.button_longPants1.TabIndex = 37;
            this.button_longPants1.Text = "Add to Cart";
            this.button_longPants1.UseVisualStyleBackColor = true;
            this.button_longPants1.Visible = false;
            this.button_longPants1.Click += new System.EventHandler(this.button_longPants1_Click);
            // 
            // button_pants3
            // 
            this.button_pants3.Location = new System.Drawing.Point(412, 308);
            this.button_pants3.Name = "button_pants3";
            this.button_pants3.Size = new System.Drawing.Size(117, 36);
            this.button_pants3.TabIndex = 36;
            this.button_pants3.Text = "Add to Cart";
            this.button_pants3.UseVisualStyleBackColor = true;
            this.button_pants3.Visible = false;
            this.button_pants3.Click += new System.EventHandler(this.button_pants3_Click);
            // 
            // button_pants2
            // 
            this.button_pants2.Location = new System.Drawing.Point(233, 308);
            this.button_pants2.Name = "button_pants2";
            this.button_pants2.Size = new System.Drawing.Size(117, 36);
            this.button_pants2.TabIndex = 35;
            this.button_pants2.Text = "Add to Cart";
            this.button_pants2.UseVisualStyleBackColor = true;
            this.button_pants2.Visible = false;
            this.button_pants2.Click += new System.EventHandler(this.button_pants2_Click);
            // 
            // button_pants1
            // 
            this.button_pants1.Location = new System.Drawing.Point(57, 308);
            this.button_pants1.Name = "button_pants1";
            this.button_pants1.Size = new System.Drawing.Size(117, 36);
            this.button_pants1.TabIndex = 34;
            this.button_pants1.Text = "Add to Cart";
            this.button_pants1.UseVisualStyleBackColor = true;
            this.button_pants1.Visible = false;
            this.button_pants1.Click += new System.EventHandler(this.button_pants1_Click);
            // 
            // button_shirt3
            // 
            this.button_shirt3.Location = new System.Drawing.Point(412, 308);
            this.button_shirt3.Name = "button_shirt3";
            this.button_shirt3.Size = new System.Drawing.Size(117, 36);
            this.button_shirt3.TabIndex = 33;
            this.button_shirt3.Text = "Add to Cart";
            this.button_shirt3.UseVisualStyleBackColor = true;
            this.button_shirt3.Visible = false;
            this.button_shirt3.Click += new System.EventHandler(this.button_shirt3_Click);
            // 
            // button_shirt2
            // 
            this.button_shirt2.Location = new System.Drawing.Point(233, 308);
            this.button_shirt2.Name = "button_shirt2";
            this.button_shirt2.Size = new System.Drawing.Size(117, 36);
            this.button_shirt2.TabIndex = 32;
            this.button_shirt2.Text = "Add to Cart";
            this.button_shirt2.UseVisualStyleBackColor = true;
            this.button_shirt2.Visible = false;
            this.button_shirt2.Click += new System.EventHandler(this.button_shirt2_Click);
            // 
            // button_shirt1
            // 
            this.button_shirt1.Location = new System.Drawing.Point(57, 308);
            this.button_shirt1.Name = "button_shirt1";
            this.button_shirt1.Size = new System.Drawing.Size(117, 36);
            this.button_shirt1.TabIndex = 31;
            this.button_shirt1.Text = "Add to Cart";
            this.button_shirt1.UseVisualStyleBackColor = true;
            this.button_shirt1.Visible = false;
            this.button_shirt1.Click += new System.EventHandler(this.button_shirt1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button_addToCardUpload);
            this.panel2.Controls.Add(this.textBox_itemName);
            this.panel2.Controls.Add(this.textBox_itemPrice);
            this.panel2.Controls.Add(this.label_itemName);
            this.panel2.Controls.Add(this.label_itemPrice);
            this.panel2.Controls.Add(this.button_upload);
            this.panel2.Controls.Add(this.label_uploadImage);
            this.panel2.Controls.Add(this.pictureBox_upload);
            this.panel2.Location = new System.Drawing.Point(22, 46);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(544, 349);
            this.panel2.TabIndex = 29;
            this.panel2.UseWaitCursor = true;
            this.panel2.Visible = false;
            // 
            // button_remove
            // 
            this.button_remove.Location = new System.Drawing.Point(851, 390);
            this.button_remove.Name = "button_remove";
            this.button_remove.Size = new System.Drawing.Size(88, 32);
            this.button_remove.TabIndex = 30;
            this.button_remove.Text = "Remove ";
            this.button_remove.UseVisualStyleBackColor = true;
            this.button_remove.Click += new System.EventHandler(this.button_remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1121, 619);
            this.Controls.Add(this.button_remove);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox_total);
            this.Controls.Add(this.textBox_subTotal);
            this.Controls.Add(this.label_total);
            this.Controls.Add(this.label_subTotal);
            this.Controls.Add(this.dgrv_quantity);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrv_quantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_upload)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_item3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_item2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_item1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem shirttoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgrv_quantity;
        private System.Windows.Forms.Label label_subTotal;
        private System.Windows.Forms.Label label_total;
        private System.Windows.Forms.TextBox textBox_subTotal;
        private System.Windows.Forms.TextBox textBox_total;
        private System.Windows.Forms.PictureBox pictureBox_item1;
        private System.Windows.Forms.PictureBox pictureBox_item2;
        private System.Windows.Forms.PictureBox pictureBox_item3;
        private System.Windows.Forms.Label label_item1;
        private System.Windows.Forms.Label label_item2;
        private System.Windows.Forms.Label label_item3;
        private System.Windows.Forms.Label label_price1;
        private System.Windows.Forms.Label label_price2;
        private System.Windows.Forms.Label label_price3;
        private System.Windows.Forms.Button button_Tshirt1;
        private System.Windows.Forms.Button button_TShirt2;
        private System.Windows.Forms.Button button_Tshirt3;
        private System.Windows.Forms.PictureBox pictureBox_upload;
        private System.Windows.Forms.Label label_uploadImage;
        private System.Windows.Forms.Button button_upload;
        private System.Windows.Forms.Label label_itemPrice;
        private System.Windows.Forms.Label label_itemName;
        private System.Windows.Forms.TextBox textBox_itemPrice;
        private System.Windows.Forms.TextBox textBox_itemName;
        private System.Windows.Forms.Button button_addToCardUpload;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.Button button_remove;
        private System.Windows.Forms.Button button_shirt1;
        private System.Windows.Forms.Button button_shirt3;
        private System.Windows.Forms.Button button_shirt2;
        private System.Windows.Forms.Button button_longPants3;
        private System.Windows.Forms.Button button_longPants2;
        private System.Windows.Forms.Button button_longPants1;
        private System.Windows.Forms.Button button_pants3;
        private System.Windows.Forms.Button button_pants2;
        private System.Windows.Forms.Button button_pants1;
        private System.Windows.Forms.Button button_jewelry3;
        private System.Windows.Forms.Button button_jewelry2;
        private System.Windows.Forms.Button button_jewelry1;
        private System.Windows.Forms.Button button_shoes3;
        private System.Windows.Forms.Button button_shoes2;
        private System.Windows.Forms.Button button_shoes1;
    }
}

