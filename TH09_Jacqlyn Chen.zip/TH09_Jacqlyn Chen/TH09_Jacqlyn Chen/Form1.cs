﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace TH09_Jacqlyn_Chen
{
    public partial class Form1 : Form
    {
        DataTable dtProduk = new DataTable();
        List<int> priceItem1 = new List<int>();
        List<int> priceItem2 = new List<int>();
        List<int> priceItem3 = new List<int>();
        int index = 0;
        int subtotal = 0;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            panel2.Visible = false;
            dtProduk.Columns.Add("Item Name");
            dtProduk.Columns.Add("Quantity");
            dtProduk.Columns.Add("Price");
            dtProduk.Columns.Add("Total");
            

            dgrv_quantity.DataSource = dgrv_quantity;
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            index = 0;
            panel1.Visible = true;
            button_Tshirt1.Visible = true;
            button_TShirt2.Visible = true;
            button_Tshirt3.Visible = true;          
            label_item1.Text = "Coffe Periodik";
            label_item2.Text = "Tea Shirt";     
            label_item3.Text = "Drink Water";
            int price1 = 125000;
            int price2 = 150000;
            int price3 = 140000;
            label_price1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            pictureBox_item1.Image = Properties.Resources.coffePeriodik;
            pictureBox_item2.Image = Properties.Resources.teaShirt;
            pictureBox_item3.Image = Properties.Resources.drinkWater;
            priceItem1.Add(price1);
            priceItem2.Add(price2);
            priceItem3.Add(price3);
        }

        private void shirttoolStripMenuItem_Click(object sender, EventArgs e)
        {
            index = 1;
            panel1.Visible = true;
            button_shirt1.Visible = true;
            button_shirt2.Visible = true;
            button_shirt3.Visible = true;
            label_item1.Text = "Green Forest Shirt";
            label_item2.Text = "Pastel Flower Shirt";
            label_item3.Text = "Lime Fruit Shirt";
            int price1 = 219000;
            int price2 = 249000;
            int price3 = 199000;
            label_price1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            pictureBox_item1.Image = Properties.Resources.greenForest;
            pictureBox_item2.Image = Properties.Resources.pastelFlower;
            pictureBox_item3.Image = Properties.Resources.limeFruit;
            priceItem1.Add(price1);
            priceItem2.Add(price2);
            priceItem3.Add(price3);
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            index = 3;
            panel1.Visible = true;
            button_pants1.Visible = true;
            button_pants2.Visible = true;
            button_pants3.Visible = true;
            label_item1.Text = "Short Cargo Style";
            label_item2.Text = "Korean Style Skort";
            label_item3.Text = "Wing Short Pants";
            int price1 = 450000;
            int price2 = 470000;
            int price3 = 529000;
            label_price1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            pictureBox_item1.Image = Properties.Resources.shortCargo;
            pictureBox_item2.Image = Properties.Resources.koreanSkort;
            pictureBox_item3.Image = Properties.Resources.wingPants;
            priceItem1.Add(price1);
            priceItem2.Add(price2);
            priceItem3.Add(price3);
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            index = 4;
            panel1.Visible = true;
            button_longPants1.Visible = true;
            button_longPants2.Visible = true;
            button_longPants3.Visible = true;
            label_item1.Text = "Flawless Army";
            label_item2.Text = "Straight Pants Brown";
            label_item3.Text = "Cargo Sage Green";
            int price1 = 779000;
            int price2 = 550000;
            int price3 = 699000;
            label_price1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            pictureBox_item1.Image = Properties.Resources.flawlessArmy;
            pictureBox_item2.Image = Properties.Resources.straightBrown;
            pictureBox_item3.Image = Properties.Resources.cargoSage;
            priceItem1.Add(price1);
            priceItem2.Add(price2);
            priceItem3.Add(price3);
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            index = 5;
            panel1.Visible = true;
            button_shoes1.Visible = true;
            button_shoes2.Visible = true;
            button_shoes3.Visible = true;
            label_item1.Text = "Beige Converse";
            label_item2.Text = "White Boots";
            label_item3.Text = "White Heels";
            int price1 = 1480000;
            int price2 = 899000;
            int price3 = 959000;
            label_price1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            pictureBox_item1.Image = Properties.Resources.converse;
            pictureBox_item2.Image = Properties.Resources.boots;
            pictureBox_item3.Image = Properties.Resources.heels;
            priceItem1.Add(price1);
            priceItem2.Add(price2);
            priceItem3.Add(price3);
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            index = 6;
            panel1.Visible = true;
            button_jewelry1.Visible = true;
            button_jewelry2.Visible = true;
            button_jewelry3.Visible = true;
            label_item1.Text = "Layered Golden Necklaces";
            label_item2.Text = "Sterling Silver Heart";
            label_item3.Text = "Double Layered Butterfly";
            int price1 = 320000;
            int price2 = 225000;
            int price3 = 266000;
            label_price1.Text = "Rp. " + price1.ToString("C").Remove(price1.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price2.Text = "Rp. " + price2.ToString("C").Remove(price2.ToString("C").Length - 3, 3).Remove(0, 2) + ".-";
            label_price3.Text = "Rp. " + price3.ToString("C").Remove(price3.ToString("C").Length - 3, 3).Remove(0, 2) + ".-"; 
            pictureBox_item1.Image = Properties.Resources.necklaces;
            pictureBox_item2.Image = Properties.Resources.earrings;
            pictureBox_item3.Image = Properties.Resources.rings;
            priceItem1.Add(price1);
            priceItem2.Add(price2);
            priceItem3.Add(price3);
        }

        private void button_item1_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Coffe Periodik")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]); 
                    angkaSementara += 1;    
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Coffe Periodik", "1", "125000", "125000");
            }          
            subtotal += 125000; 
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk; 
        }

        private void button_TShirt2_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Tea Shirt")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Tea Shirt", "1", "150000", "150000");
            }
            subtotal += 150000; 
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }
        
        private void button_Tshirt3_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Drink Water")
                { 
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]); 
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Drink Water", "1", "140000", "140000");
            }
            subtotal += 140000; 
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }
        private void button_shirt1_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Green Forest Shirt")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Green Forest Shirt", "1", "219000", "219000");
            }
            subtotal += 219000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_shirt2_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Pastel Flower Shirt")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Pastel Flower Shirt", "1", "249000", "249000");
            }
            subtotal += 249000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_shirt3_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Lime Fruit Shirt")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]); 
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Lime Fruit Shirt", "1", "199000", "199000");
            }
            subtotal += 199000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }
        private void button_pants1_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Short Cargo Style")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Short Cargo Style", "1", "450000", "450000");
            }
            subtotal += 450000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_pants2_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Korean Style Skort")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Korean Style Skort", "1", "470000", "470000");
            }
            subtotal += 470000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_pants3_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Wing Short Style")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]); 
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Wing Short Style", "1", "529000", "529000");
            }
            subtotal += 529000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_longPants1_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Flawless Army")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Flawless Army", "1", "779000", "779000");
            }
            subtotal += 779000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_longPants2_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Straight Pants Brown")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Straight Pants Brown", "1", "559000", "559000");
            }
            subtotal += 559000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_longPants3_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Cargo Sage Green")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Cargo Sage Green", "1", "699000", "699000");
            }
            subtotal += 699000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_shoes1_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Beige Converse")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Beige Converse", "1", "1480000", "1480000");
            }
            subtotal += 1480000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_shoes2_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "White Boots")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("White Boots", "1", "899000", "899000");
            }
            subtotal += 899000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_shoes3_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "White Heels")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("White Heels", "1", "959000", "959000");
            }
            subtotal += 959000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_jewelry1_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Layered Golden Necklaces")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Layered Golden Necklaces", "1", "320000", "320000");
            }
            subtotal += 320000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_jewelry2_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Sterling Silver Heart")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Sterling Silver Heart", "1", "225000", "225000");
            }
            subtotal += 225000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_jewelry3_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == "Double Layerred Butterfly")
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add("Double Layerred Butterfly", "1", "226000", "226000");
            }
            subtotal += 226000;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
        }

        private void button_remove_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow item in this.dgrv_quantity.SelectedRows)
            {
                dgrv_quantity.Rows.RemoveAt(item.Index);
            }
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            index = 7;
            panel2.Visible = true;
        }

        private void button_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files(*.jpg, *.jpeg, *.png)|*.jpg; *.jpeg; *.png";
            ofd.ShowDialog();
            pictureBox_upload.Image = new Bitmap(ofd.FileName);
            pictureBox_upload.SizeMode = PictureBoxSizeMode.StretchImage;
            textBox_itemName.Visible = true;
            textBox_itemPrice.Visible = true;
        }

        private void button_addToCardUpload_Click(object sender, EventArgs e)
        {
            bool adaBarang = false;
            int tbprice = Convert.ToInt32(textBox_itemPrice.Text);
            
            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == textBox_itemName.Text)
                {
                    adaBarang = true;
                    int angkaSementara = Convert.ToInt32(dtProduk.Rows[i][1]);
                    angkaSementara += 1;
                    dtProduk.Rows[i][1] = angkaSementara.ToString();
                    break;
                }
            }
            if (adaBarang == false)
            {
                dtProduk.Rows.Add(textBox_itemName.Text, "1", tbprice, tbprice);
            }
            subtotal += tbprice;
            textBox_subTotal.Text = subtotal.ToString();
            textBox_total.Text = (subtotal + subtotal * 0.1).ToString();
            dgrv_quantity.DataSource = dtProduk;
            textBox_itemName.Clear();
            textBox_itemPrice.Clear();
        }

        bool cek = false;
        bool cekk = false;
        private void textBox_itemName_TextChanged(object sender, EventArgs e)
        {
            if (textBox_itemName.Text == "")
            {
                cek = false;
            }
            else
            {
                cek = true;
            }

            if (cekk == false)
            {
                button_addToCardUpload.Enabled = false;
            }
            else if (cek == true && cekk == true)
            {
                button_addToCardUpload.Enabled = true;
            }
        }

        private void textBox_itemPrice_TextChanged(object sender, EventArgs e)
        {
            if (textBox_itemPrice.Text == "")
            {
                cekk = false;
            }
            else
            {
                cekk = true;
            }

            if (cekk == false)
            {
                button_addToCardUpload.Enabled = false;
            }
            else if (cek == true && cekk == true)
            {
                button_addToCardUpload.Enabled = true;
            }
        }

        private void textBox_itemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
