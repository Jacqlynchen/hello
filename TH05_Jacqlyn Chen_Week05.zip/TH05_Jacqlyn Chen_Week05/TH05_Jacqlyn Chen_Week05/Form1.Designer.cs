﻿namespace TH05_Jacqlyn_Chen_Week05
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_product = new System.Windows.Forms.Label();
            this.lb_category = new System.Windows.Forms.Label();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.dataGridView_Product = new System.Windows.Forms.DataGridView();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.dataGridView_Category = new System.Windows.Forms.DataGridView();
            this.lb_detail = new System.Windows.Forms.Label();
            this.lb_nama = new System.Windows.Forms.Label();
            this.lb_categoryy = new System.Windows.Forms.Label();
            this.lb_harga = new System.Windows.Forms.Label();
            this.lb_stock = new System.Windows.Forms.Label();
            this.tb_namaProduct = new System.Windows.Forms.TextBox();
            this.tb_stock = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.btn_addProduct = new System.Windows.Forms.Button();
            this.btn_editProduct = new System.Windows.Forms.Button();
            this.btn_removeProduct = new System.Windows.Forms.Button();
            this.lb_namaCategory = new System.Windows.Forms.Label();
            this.tb_namaCategory = new System.Windows.Forms.TextBox();
            this.btn_addCategory = new System.Windows.Forms.Button();
            this.btn_removeCategory = new System.Windows.Forms.Button();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_product
            // 
            this.lb_product.AutoSize = true;
            this.lb_product.Font = new System.Drawing.Font("Trebuchet MS", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_product.Location = new System.Drawing.Point(33, 4);
            this.lb_product.Name = "lb_product";
            this.lb_product.Size = new System.Drawing.Size(117, 36);
            this.lb_product.TabIndex = 0;
            this.lb_product.Text = "Product";
            // 
            // lb_category
            // 
            this.lb_category.AutoSize = true;
            this.lb_category.Font = new System.Drawing.Font("Trebuchet MS", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_category.Location = new System.Drawing.Point(573, 4);
            this.lb_category.Name = "lb_category";
            this.lb_category.Size = new System.Drawing.Size(131, 36);
            this.lb_category.TabIndex = 1;
            this.lb_category.Text = "Category";
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(212, 35);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(76, 28);
            this.btn_all.TabIndex = 2;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(294, 35);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(67, 28);
            this.btn_filter.TabIndex = 3;
            this.btn_filter.Text = "Filter";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // dataGridView_Product
            // 
            this.dataGridView_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Product.Location = new System.Drawing.Point(24, 69);
            this.dataGridView_Product.Name = "dataGridView_Product";
            this.dataGridView_Product.RowHeadersWidth = 62;
            this.dataGridView_Product.RowTemplate.Height = 28;
            this.dataGridView_Product.Size = new System.Drawing.Size(519, 244);
            this.dataGridView_Product.TabIndex = 4;
            this.dataGridView_Product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Product_CellClick);
            this.dataGridView_Product.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Product_CellContentClick);
            // 
            // cb_filter
            // 
            this.cb_filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(367, 35);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(146, 28);
            this.cb_filter.TabIndex = 5;
            this.cb_filter.SelectionChangeCommitted += new System.EventHandler(this.cb_filter_SelectionChangeCommitted);
            // 
            // dataGridView_Category
            // 
            this.dataGridView_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Category.Location = new System.Drawing.Point(579, 69);
            this.dataGridView_Category.Name = "dataGridView_Category";
            this.dataGridView_Category.RowHeadersWidth = 62;
            this.dataGridView_Category.RowTemplate.Height = 28;
            this.dataGridView_Category.Size = new System.Drawing.Size(408, 244);
            this.dataGridView_Category.TabIndex = 6;
            // 
            // lb_detail
            // 
            this.lb_detail.AutoSize = true;
            this.lb_detail.Font = new System.Drawing.Font("Trebuchet MS", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_detail.Location = new System.Drawing.Point(33, 316);
            this.lb_detail.Name = "lb_detail";
            this.lb_detail.Size = new System.Drawing.Size(91, 36);
            this.lb_detail.TabIndex = 7;
            this.lb_detail.Text = "Detail";
            // 
            // lb_nama
            // 
            this.lb_nama.AutoSize = true;
            this.lb_nama.Location = new System.Drawing.Point(35, 368);
            this.lb_nama.Name = "lb_nama";
            this.lb_nama.Size = new System.Drawing.Size(59, 20);
            this.lb_nama.TabIndex = 8;
            this.lb_nama.Text = "Nama :";
            // 
            // lb_categoryy
            // 
            this.lb_categoryy.AutoSize = true;
            this.lb_categoryy.Location = new System.Drawing.Point(35, 404);
            this.lb_categoryy.Name = "lb_categoryy";
            this.lb_categoryy.Size = new System.Drawing.Size(81, 20);
            this.lb_categoryy.TabIndex = 9;
            this.lb_categoryy.Text = "Category :";
            // 
            // lb_harga
            // 
            this.lb_harga.AutoSize = true;
            this.lb_harga.Location = new System.Drawing.Point(35, 438);
            this.lb_harga.Name = "lb_harga";
            this.lb_harga.Size = new System.Drawing.Size(61, 20);
            this.lb_harga.TabIndex = 10;
            this.lb_harga.Text = "Harga :";
            // 
            // lb_stock
            // 
            this.lb_stock.AutoSize = true;
            this.lb_stock.Location = new System.Drawing.Point(35, 469);
            this.lb_stock.Name = "lb_stock";
            this.lb_stock.Size = new System.Drawing.Size(58, 20);
            this.lb_stock.TabIndex = 11;
            this.lb_stock.Text = "Stock :";
            // 
            // tb_namaProduct
            // 
            this.tb_namaProduct.Location = new System.Drawing.Point(122, 362);
            this.tb_namaProduct.Name = "tb_namaProduct";
            this.tb_namaProduct.Size = new System.Drawing.Size(421, 26);
            this.tb_namaProduct.TabIndex = 12;
            // 
            // tb_stock
            // 
            this.tb_stock.Location = new System.Drawing.Point(122, 466);
            this.tb_stock.Name = "tb_stock";
            this.tb_stock.Size = new System.Drawing.Size(139, 26);
            this.tb_stock.TabIndex = 13;
            this.tb_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stock_KeyPress);
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(122, 432);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(139, 26);
            this.tb_harga.TabIndex = 14;
            this.tb_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_harga_KeyPress);
            // 
            // btn_addProduct
            // 
            this.btn_addProduct.BackColor = System.Drawing.Color.Lime;
            this.btn_addProduct.Location = new System.Drawing.Point(276, 417);
            this.btn_addProduct.Name = "btn_addProduct";
            this.btn_addProduct.Size = new System.Drawing.Size(85, 66);
            this.btn_addProduct.TabIndex = 16;
            this.btn_addProduct.Text = "Add Product";
            this.btn_addProduct.UseVisualStyleBackColor = false;
            this.btn_addProduct.Click += new System.EventHandler(this.btn_addProduct_Click);
            // 
            // btn_editProduct
            // 
            this.btn_editProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_editProduct.Location = new System.Drawing.Point(367, 417);
            this.btn_editProduct.Name = "btn_editProduct";
            this.btn_editProduct.Size = new System.Drawing.Size(85, 66);
            this.btn_editProduct.TabIndex = 17;
            this.btn_editProduct.Text = "Edit Product";
            this.btn_editProduct.UseVisualStyleBackColor = false;
            this.btn_editProduct.Click += new System.EventHandler(this.btn_editProduct_Click);
            // 
            // btn_removeProduct
            // 
            this.btn_removeProduct.BackColor = System.Drawing.Color.Red;
            this.btn_removeProduct.Location = new System.Drawing.Point(458, 417);
            this.btn_removeProduct.Name = "btn_removeProduct";
            this.btn_removeProduct.Size = new System.Drawing.Size(85, 66);
            this.btn_removeProduct.TabIndex = 18;
            this.btn_removeProduct.Text = "Remove Product";
            this.btn_removeProduct.UseVisualStyleBackColor = false;
            this.btn_removeProduct.Click += new System.EventHandler(this.btn_removeProduct_Click);
            // 
            // lb_namaCategory
            // 
            this.lb_namaCategory.AutoSize = true;
            this.lb_namaCategory.Location = new System.Drawing.Point(575, 329);
            this.lb_namaCategory.Name = "lb_namaCategory";
            this.lb_namaCategory.Size = new System.Drawing.Size(59, 20);
            this.lb_namaCategory.TabIndex = 19;
            this.lb_namaCategory.Text = "Nama :";
            // 
            // tb_namaCategory
            // 
            this.tb_namaCategory.Location = new System.Drawing.Point(661, 326);
            this.tb_namaCategory.Name = "tb_namaCategory";
            this.tb_namaCategory.Size = new System.Drawing.Size(326, 26);
            this.tb_namaCategory.TabIndex = 20;
            // 
            // btn_addCategory
            // 
            this.btn_addCategory.BackColor = System.Drawing.Color.Lime;
            this.btn_addCategory.Location = new System.Drawing.Point(811, 362);
            this.btn_addCategory.Name = "btn_addCategory";
            this.btn_addCategory.Size = new System.Drawing.Size(85, 53);
            this.btn_addCategory.TabIndex = 21;
            this.btn_addCategory.Text = "Add Category";
            this.btn_addCategory.UseVisualStyleBackColor = false;
            this.btn_addCategory.Click += new System.EventHandler(this.btn_addCategory_Click_2);
            // 
            // btn_removeCategory
            // 
            this.btn_removeCategory.BackColor = System.Drawing.Color.Red;
            this.btn_removeCategory.Location = new System.Drawing.Point(902, 362);
            this.btn_removeCategory.Name = "btn_removeCategory";
            this.btn_removeCategory.Size = new System.Drawing.Size(85, 53);
            this.btn_removeCategory.TabIndex = 22;
            this.btn_removeCategory.Text = "Remove Category";
            this.btn_removeCategory.UseVisualStyleBackColor = false;
            this.btn_removeCategory.Click += new System.EventHandler(this.btn_removeCategory_Click);
            // 
            // cb_category
            // 
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Location = new System.Drawing.Point(122, 398);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(139, 28);
            this.cb_category.TabIndex = 23;
            this.cb_category.SelectedIndexChanged += new System.EventHandler(this.cb_category_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TH05_Jacqlyn_Chen_Week05.Properties.Resources.WhatsApp_Image_2024_03_25_at_16_30_42_aec34031;
            this.pictureBox1.Location = new System.Drawing.Point(568, 362);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(237, 154);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(1366, 561);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cb_category);
            this.Controls.Add(this.btn_removeCategory);
            this.Controls.Add(this.btn_addCategory);
            this.Controls.Add(this.tb_namaCategory);
            this.Controls.Add(this.lb_namaCategory);
            this.Controls.Add(this.btn_removeProduct);
            this.Controls.Add(this.btn_editProduct);
            this.Controls.Add(this.btn_addProduct);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.tb_stock);
            this.Controls.Add(this.tb_namaProduct);
            this.Controls.Add(this.lb_stock);
            this.Controls.Add(this.lb_harga);
            this.Controls.Add(this.lb_categoryy);
            this.Controls.Add(this.lb_nama);
            this.Controls.Add(this.lb_detail);
            this.Controls.Add(this.dataGridView_Category);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.dataGridView_Product);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.lb_category);
            this.Controls.Add(this.lb_product);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_product;
        private System.Windows.Forms.Label lb_category;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.DataGridView dataGridView_Product;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.DataGridView dataGridView_Category;
        private System.Windows.Forms.Label lb_detail;
        private System.Windows.Forms.Label lb_nama;
        private System.Windows.Forms.Label lb_categoryy;
        private System.Windows.Forms.Label lb_harga;
        private System.Windows.Forms.Label lb_stock;
        private System.Windows.Forms.TextBox tb_namaProduct;
        private System.Windows.Forms.TextBox tb_stock;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.Button btn_addProduct;
        private System.Windows.Forms.Button btn_editProduct;
        private System.Windows.Forms.Button btn_removeProduct;
        private System.Windows.Forms.Label lb_namaCategory;
        private System.Windows.Forms.TextBox tb_namaCategory;
        private System.Windows.Forms.Button btn_addCategory;
        private System.Windows.Forms.Button btn_removeCategory;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

