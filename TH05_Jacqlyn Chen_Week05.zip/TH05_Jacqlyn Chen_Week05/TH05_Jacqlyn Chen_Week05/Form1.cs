﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace TH05_Jacqlyn_Chen_Week05
{
    public partial class Form1 : Form
    {
        public Form1()
        {            
            InitializeComponent();
        }
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();
        string idproduct;

        private void Form1_Load(object sender, EventArgs e)
        {
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obssessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");

            dtProdukTampil = dtProdukSimpan.Copy();
            dataGridView_Product.DataSource = dtProdukTampil;
            dataGridView_Category.DataSource = dtCategory;
            
            cb_filter.DisplayMember = "Nama Category"; //buat nampilin nama category di filter
            cb_filter.ValueMember = "ID Category"; // ibarat kayak nim value sesutau yg ga keliatan
            cb_filter.DataSource = dtCategory;
            cb_filter.Enabled = false;
            cb_filter.Text = " "; //buat kosongin filter pas awal
            cb_filter.SelectedIndex = -1;

            cb_category.DisplayMember = "Nama Category";
            cb_category.ValueMember = "ID Category";
            cb_category.DataSource = dtCategory;
            cb_category.Enabled = true;
            cb_category.Text = " ";
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = false;
            cb_filter.Text = " ";
            dtProdukTampil.Clear();
            dtProdukTampil = dtProdukSimpan.Copy();
            dataGridView_Product.DataSource = dtProdukTampil;
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = true;
        }

        private void dataGridView_Product_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string categoryFilter = cb_filter.SelectedValue.ToString();
            if(categoryFilter == "All")
            {
                dtProdukTampil = dtProdukSimpan.Copy();
            }
            else
            {
                dtProdukTampil = dtProdukSimpan.AsEnumerable().Where(row => row.Field<string>("ID Category") == categoryFilter).CopyToDataTable();
            }
            dataGridView_Product.DataSource = dtProdukSimpan;
            
        }

        private void btn_addProduct_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (tb_namaProduct.Text != "")
            {
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (tb_namaProduct.Text.ToString().Substring(0, 1).ToUpper() == dtProdukSimpan.Rows[i][0].ToString().Substring(0, 1))
                    {
                        count++;
                    }
                }
            }
            if (count <= 99)
            {
                idproduct = tb_namaProduct.Text.ToString().Substring(0, 1).ToUpper() + "00" + (count + 1);
            }
            else
            {
                idproduct = tb_namaProduct.Text.ToString().Substring(0, 1).ToUpper() + (count + 1);
            }

            DataRow newrow = dtProdukSimpan.NewRow();
            newrow["id product"] = idproduct;
            newrow["nama product"] = tb_namaProduct.Text;
            newrow["harga"] = tb_harga.Text;
            newrow["stock"] = tb_stock.Text;
            newrow["ID Category"] = cb_category.SelectedValue;
            dtProdukSimpan.Rows.Add(newrow);

            if (string.IsNullOrWhiteSpace(tb_namaProduct.Text) || string.IsNullOrWhiteSpace(tb_harga.Text) || string.IsNullOrWhiteSpace(tb_stock.Text))
            {
                MessageBox.Show("please fill in all fields. ", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            tb_namaProduct.Clear();
            cb_category.Text = " ";
            tb_harga.Clear();
            tb_stock.Clear();
            dtProdukTampil.Clear();
            dtProdukTampil = dtProdukSimpan.Copy();
            dataGridView_Product.DataSource = dtProdukTampil;
        }
        
        private void cb_category_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selecetedCategory = cb_category.SelectedItem.ToString();
        }

        private void btn_addCategory_Click(object sender, EventArgs e)
        {

        }

        private void tb_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void tb_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

       
        
        private void btn_editProduct_Click(object sender, EventArgs e)
        {
            foreach (DataRow dt in dtProdukSimpan.Rows)
            {
                if (dt[1].ToString() == tb_namaProduct.Text)
                {
                    dt[1] = tb_namaProduct.Text;
                    dt[2] = tb_harga.Text;
                    dt[3] = tb_stock.Text;
                    dt[4] = cb_category.SelectedValue;
                }
            }
            dtProdukTampil.Clear();
            dtProdukTampil = dtProdukSimpan.Copy();
            dataGridView_Product.DataSource = dtProdukTampil;
        }

        private void dataGridView_Product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string abc = "";
            foreach (DataRow dt in dtCategory.Rows)
            {
                if (dt[0].ToString() == dataGridView_Product.Rows[e.RowIndex].Cells[4].Value.ToString())
                {
                    abc = dt[1].ToString();
                }
            }
            
            tb_namaProduct.Text = dataGridView_Product.Rows[e.RowIndex].Cells[1].Value.ToString();
            cb_category.Text = abc;
            tb_harga.Text = dataGridView_Product.Rows[e.RowIndex].Cells[2].Value.ToString();
            tb_stock.Text = dataGridView_Product.Rows[e.RowIndex].Cells[3].Value.ToString();  
        }

        private void btn_removeProduct_Click(object sender, EventArgs e)
        {           
            int selectedrowindex = dataGridView_Product.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridView_Product.Rows[selectedrowindex];
            string cellValue = Convert.ToString(selectedRow.Cells["ID Product"].Value);

            int indexProduk = 0;
            foreach (DataRow dt in dtProdukSimpan.Rows)
            {
                if(cellValue == dt[0].ToString())
                {
                    break;
                }
                indexProduk++;
            }

            dtProdukSimpan.Rows.RemoveAt(indexProduk);
            dataGridView_Product.DataSource = dtProdukSimpan;
        }

        private void btn_removeCategory_Click(object sender, EventArgs e)
        {           
            int selectedrowindex = dataGridView_Category.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dataGridView_Category.Rows[selectedrowindex];
            string cellValue = Convert.ToString(selectedRow.Cells["ID Category"].Value);

            int indexProduk = 0;
            foreach (DataRow dt in dtCategory.Rows)
            {      
                if (cellValue == dt[0].ToString())
                {
                    break;
                }
                indexProduk++;
            }
            dtCategory.Rows.RemoveAt(indexProduk);
            dataGridView_Category.DataSource = dtCategory;
        }

        private void btn_addCategory_Click_2(object sender, EventArgs e)
        {
            bool samadengan = false;
            foreach (DataRow row in dtCategory.Rows)
            {
                if (row[1].ToString() == tb_namaCategory.Text)
                {
                    samadengan = true;
                }
            }

            if (samadengan == true)
            {
                MessageBox.Show("Sudah ada nama kategori tersebut");
            }
            else
            {
                int number = 0;
                foreach (DataRow row in dtCategory.Rows)
                {
                    number++;
                }
                number = number + 1;
                dtCategory.Rows.Add("C" + number, tb_namaCategory.Text);
                dataGridView_Category.DataSource = dtCategory;
                cb_filter.DisplayMember = "Nama Category";
                cb_filter.ValueMember = "ID Category";
                cb_filter.DataSource = dtCategory;
                cb_filter.Enabled = true;
                cb_category.DisplayMember = "Nama Category";
                cb_category.ValueMember = "ID Category";
                cb_category.DataSource = dtCategory;
                cb_category.Enabled = true;
                tb_namaCategory.Clear();
            }
        }

        private void cb_filter_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cb_filter.Text.ToString() != null)
            {
                dtProdukTampil.Rows.Clear();
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][4] == cb_filter.SelectedValue)
                    {
                        DataRow newrow = dtProdukTampil.NewRow();
                        newrow["id product"] = dtProdukSimpan.Rows[i][0];
                        newrow["nama product"] = dtProdukSimpan.Rows[i][1];
                        newrow["harga"] = dtProdukSimpan.Rows[i][2];
                        newrow["stock"] = dtProdukSimpan.Rows[i][3];
                        newrow["ID Category"] = dtProdukSimpan.Rows[i][4];
                        dtProdukTampil.Rows.Add(newrow);
                        dataGridView_Product.DataSource = dtProdukTampil;
                    }
                }
            }
        }
    }
}
